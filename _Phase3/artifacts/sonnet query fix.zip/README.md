# Sonnet query rewrite + portrait threshold tightening

Closes Phase3.md §7.3 + §7.4 jointly. Two coordinated fixes:

## A. Source-aware queries

**Root cause** (proven from your decisions.json):
- Sonnet rule 6 said "specific and named" — produced encyclopedic queries
- Pexels (stock site) can't find named figures → keyword-matches "Iraqi"
  → returns Iraqi Airways planes
- Wikimedia/LoC need the named entity; Pexels needs visual descriptors
- Single-query-for-all-sources can't satisfy both

**Fix**: rewrite `_SYSTEM_PROMPT` rule 6 in `phase3/plan.py` (the per-shot
query generator) and the wikimedia/pexels rules in `phase3/keywords.py`
(section-level pool) to write queries that lead with the named entity
(for Wikimedia/LoC) AND append visual descriptors (for Pexels fallback).

Before: `Jafar al-Askari Iraqi officer historical portrait` → businessman
exits Iraqi Airways plane

After:  `Jafar al-Askari Ottoman military officer mustache sepia portrait
early 1900s` → Wikimedia matches Jafar; Pexels still gets a
period-appropriate fallback

## B. Portrait threshold tightening

**Root cause**: `passes_threshold` accepted `subject >= 1` ("vaguely
related, wrong era/region"). Acceptable for B-roll; jarring for portraits.

**Fix**: `MIN_KEEP_SUBJECT_PORTRAIT = 2` ("right era/region, wrong
specific person" still passes; pure topical drift like "Iraqi → Iraqi
Airways" is rejected). Threaded through `fetch_for_shot(visual_type=...)`
and `prebuild_assets.py`.

When all portrait candidates fail the floor, the orchestrator already
returns `best=None` and the renderer falls back to typography or
placeholder.

## Files

| Path                            | Change                                |
|---------------------------------|---------------------------------------|
| `phase3/plan.py`                | Rule 6 rewrite                        |
| `phase3/keywords.py`            | wikimedia/pexels rules rewrite        |
| `phase3/sources/vision.py`      | New constant, visual-type-aware       |
| `phase3/sources/__init__.py`    | Thread `visual_type` through         |
| `prebuild_assets.py`            | Pass `shot.visual` to fetcher        |

## Apply

```bash
!unzip -o /content/sonnet_query_fix.zip -d /tmp/sqf
!cp /tmp/sqf/phase3/plan.py /content/phase3/
!cp /tmp/sqf/phase3/keywords.py /content/phase3/
!cp /tmp/sqf/phase3/sources/vision.py /content/phase3/sources/
!cp /tmp/sqf/phase3/sources/__init__.py /content/phase3/sources/
!cp /tmp/sqf/prebuild_assets.py /content/
!find /content -name __pycache__ -exec rm -rf {} + 2>/dev/null
```

## Re-plan required

Sonnet's prompt changed → the cached plan has old-style queries. You
need to re-run the planner step to regenerate `al_askari_plan_v2.json`,
then re-run `prebuild_assets.py` (which re-scores against the new
threshold).

## Expected impact on your sample shots

| Shot | Old chosen | Expected with new query |
|------|-----------|-------------------------|
| #5 portrait | "businessman Iraqi Airways" (subject=1) | rejected → typography fallback OR period officer portrait |
| #6 location | "Suleymaniye Mosque rooftops" | similar (already era-correct) |
| #12 location | "Izmir Clock Tower" | "Tigris river Mosul" descriptors give better match |
| #20 portrait | "Blue Mosque dome" (subject=1) | rejected → typography fallback |
| #41 broll | "Palestinian flag" | "1916 sepia desert banner" gives better match |

Portrait shots that can't find anything good will now fall back rather
than ship a wrong-subject image.
