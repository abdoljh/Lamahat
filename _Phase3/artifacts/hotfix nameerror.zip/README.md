# Hotfix: NameError in fetch_for_shot — blocked all candidates

## Root cause

Last patch threaded `visual_type` through `Fetcher.fetch_for_shot` and the
two `passes_threshold` calls — but missed that the second call sits
*inside* `_fetch_live(query, shot_index)`, which has no `visual_type`
parameter. Result: `NameError: name 'visual_type' is not defined` on
every shot, caught by `prebuild_assets.py`'s `except Exception`, which
emits an empty `candidates.json`. Pexels was actually returning 3
candidates per shot — they just never reached disk.

## Fix

1. `_fetch_live(self, query, shot_index, visual_type=None)` — added param
2. Caller `_fetch_live(query, shot_index)` → `_fetch_live(query, shot_index, visual_type)`
3. `prebuild_assets.py` passes `shot.visual` (this was correct in last patch but re-applied here for completeness)

## Why Wikimedia/IA return 0

Two factors:

1. **Wikimedia full-text search treats long queries as AND-of-all-terms.**
   `"Jafar al-Askari Iraqi Ottoman military officer sepia portrait early 1900s uniform"`
   requires ALL 13 tokens to appear in the file description text. Almost
   no Commons file has all 13. Google does fuzzy/relevance matching;
   MediaWiki search does literal token AND.

2. **Pexels works on long queries** (its index is more permissive on
   captions), which is why you saw `Pexels: 3 candidates` consistently.

The right fix for Wikimedia is **query simplification** — try the
short named query FIRST, then fall back to longer variants. But that's
a separate patch and requires careful design. **This hotfix only
restores the previous behaviour** (Pexels candidates reach disk).

## Apply

```bash
!unzip -o /content/hotfix_nameerror.zip -d /tmp/hot
!cp /tmp/hot/phase3/sources/__init__.py /content/phase3/sources/
!cp /tmp/hot/phase3/sources/vision.py /content/phase3/sources/
!cp /tmp/hot/prebuild_assets.py /content/
!find /content -name __pycache__ -exec rm -rf {} + 2>/dev/null
```

No re-plan needed — the cached plan from the last run is fine.
Just re-run `prebuild_assets.py` and the candidates will reach disk.

## What to expect after applying

- Pexels-3 candidates per shot will appear in `candidates.json`
- Vision scorer will rank them
- Portrait shots with subject-score < 2 will reject (the §7.4 floor
  from the last patch) — those land on typography fallback
- Non-portrait shots use the old subject-score-1 floor (B-roll passes)

## Next step (separate patch, not in this zip)

Wikimedia query simplification: search short→long, return first non-empty.
