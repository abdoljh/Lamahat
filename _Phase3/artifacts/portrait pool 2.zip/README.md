# Portrait pool + book cover auto-discovery (repo-root layout)

## Layout

```
<repo_root>/
├── output/
│   └── review/        ← decisions.json lives here
├── overrides/         ← user-supplied images (sibling of output/)
│   ├── character/     ← portrait pool — drop *.jpg/*.png here
│   │   ├── 01_jafar_1918.jpg
│   │   ├── 02_jafar_official.jpg
│   │   └── 03_jafar_late_career.jpg
│   └── book_cover.jpg
└── samples/
```

## Behaviour

**Portrait shots**: round-robin through sorted files in
`<repo_root>/overrides/character/` (by portrait-shot rank, modulo-wrapped).

**Title card**: auto-discovers `<repo_root>/overrides/book_cover.{jpg,jpeg,png,webp}`
when neither `--book-cover` nor `book.cover_path` resolves.

No `decisions.json` edit required. Re-running the notebook
end-to-end doesn't lose either override.

## Resolution chain

| Image | Order |
|---|---|
| Portrait shot | 1. `overrides/character/` pool → 2. legacy `pinned_portrait` file → 3. `chosen_file` |
| Title card cover | 1. `--book-cover` CLI → 2. `book.cover_path` in dossier → 3. `overrides/book_cover.*` auto-discovery |

Repo-root discovery walks up from `review_dir` until it finds an
`overrides/` sibling (max 3 levels).

## Files

| Path | Change |
|---|---|
| `phase3/sources/decisions.py` | Pool reads `<repo_root>/overrides/character/` |
| `render_plan.py` | Book cover auto-discovery from `<repo_root>/overrides/` |

## Apply

```bash
!unzip -o /content/portrait_pool.zip -d /tmp/pp
!cp /tmp/pp/phase3/sources/decisions.py /content/phase3/sources/
!cp /tmp/pp/render_plan.py /content/
!find /content -name __pycache__ -exec rm -rf {} + 2>/dev/null
```

## Sandbox verified

```
Layout: /tmp/repo_test/{output/review, overrides/character, overrides/book_cover.jpg}
Pool root resolved: /tmp/repo_test
Pool: [portrait_0.jpg, portrait_1.jpg, portrait_2.jpg]
shot  2 portrait → portrait_0.jpg
shot  5 portrait → portrait_1.jpg
shot  8 portrait → portrait_2.jpg
shot 11 portrait → portrait_0.jpg  (wraps)
```
