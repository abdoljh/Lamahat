# Portrait pool — multi-image character override

`overrides/character.jpg` (single file) → `overrides/character/` (pool).

## Behaviour

`Decisions.pinned_portrait` now accepts either:
- a file (legacy) → all portrait shots use the same image
- a directory → portrait shots round-robin through sorted
  `*.{jpg,jpeg,png,webp}` inside it

## Round-robin order

By portrait shot rank (1st portrait shot → file 0, 2nd → file 1, ...).
Wraps via modulo, so 3 pool images cover any number of portrait shots
deterministically. Sorted by filename (case-insensitive).

## Setup

Set `decisions.json`:

```json
{ "pinned_portrait": "overrides/character" }
```

Drop portraits into `output/review/overrides/character/`. Naming free —
sort order = filename order:

```
overrides/character/
├── 01_jafar_1918_uniform.jpg
├── 02_jafar_official_portrait.jpg
└── 03_jafar_late_career.jpg
```

## Apply

```bash
!unzip -o /content/portrait_pool.zip -d /tmp/pp
!cp /tmp/pp/phase3/sources/decisions.py /content/phase3/sources/
!find /content -name __pycache__ -exec rm -rf {} + 2>/dev/null
```

No re-plan needed. Affects portrait shots only — title card's
`book.cover_path` unchanged.

## Sandbox verified

```
Pool files (3): portrait_0.jpg portrait_1.jpg portrait_2.jpg
shot  2 portrait → portrait_0.jpg
shot  5 portrait → portrait_1.jpg
shot  8 portrait → portrait_2.jpg
shot 11 portrait → portrait_0.jpg  (wraps)
```

Backward compat: single file path still resolves identically.
