# Issue 4 patch A v3.1 — title card + caption rendering

## Verifying first

After applying, run from `_Phase3/`:

```bash
python diagnose_issue4.py --review-dir output/review/
python diagnose_captions.py --plan output/al_askari_plan_v2.json
```

**Both must report v3 changes**, not just gap/MIN_VISIBLE.  Specifically:

- `diagnose_issue4.py` must show **all** of:
  - `✓ caption GAP = 0.15`
  - `✓ caption MIN_VISIBLE = 0.6`
  - `✓ ASS header has WrapStyle: 2`         ← new v3 check
  - `✓ _wrap_caption() helper present`       ← new v3 check
  - `✓ caption font size at 5.0%`            ← new v3 check

- `diagnose_captions.py` must end with:
  ```
  ✓ Gaps ~0.30s AND captions wrapped — v3 PATCH IS LIVE.
  ```
  (`Wrapped events: N/15` should be roughly equal to the number of
  captions over 8 words — typically all 15.)

If the issue4 output shows `✗ ASS header is missing WrapStyle: 2`,
**you have v2's render.py, not v3's**.  The most common cause is that
Colab cell 0 re-cloned the repo and overwrote your patched files.
Re-apply `render.py` from this bundle *after* cell 0.

## What this patch does

### Caption rendering

| Aspect | Original | v2 | v3 |
|---|---|---|---|
| Inter-event gap | 0.10 s | 0.30 s | 0.30 s |
| Font size at 1080p | 45 px (4.2%) | 45 px | 54 px (5.0%) |
| WrapStyle in ASS header | 0 | 0 | 2 |
| Horizontal margins | 80 px | 80 px | 18% of width (≈346 px) |
| Line breaking | none | none | `\N` inserted after ≈8th word |

Concrete consequence: a 13-word caption that previously read as one
small line spanning most of the frame now reads as two larger lines
of ~7 words each, centered.

### Title card

- Cover-image mode: full-frame photo + darkening gradient + aged-gold
  title, no hairlines.  Triggered when `decisions.json` has
  `book.cover_path` OR `--book-cover PATH` is passed to render_plan.
- Cream mode (unchanged from current repo, only re-sized): kept as the
  fallback when no cover is supplied.
- Title size bumped from 0.085 to 0.110 of frame height.

## Apply

Drop the four `.py` files in this bundle over their counterparts in
`_Phase3/`.

In Colab, the order matters: cell 0 clones the repo, so the patched
files must be copied to `/content/phase3/` and `/content/` **after**
cell 0 runs.  If you push these to your GitHub fork, cell 0 will pick
them up natively and the ordering problem disappears.

## Files in this bundle

| File | Purpose |
|---|---|
| `phase3/typography.py` | Drop-in replacement |
| `phase3/render.py`     | Drop-in replacement (v3 caption changes here) |
| `prebuild_assets.py`   | Drop-in replacement |
| `render_plan.py`       | Drop-in replacement |
| `*.diff` | Unified diffs against the current repo, for review |
| `verify_title_card.py` | Self-test |
| `diagnose_issue4.py`   | Patch detector with v3 checks |
| `diagnose_captions.py` | Exercises _write_captions against your plan, shows actual ASS events with wrap status |

## What's still pending (issue 4 patch B)

Caption backplate: charcoal-bar + cream-text aesthetic.  Touches the
FFmpeg mux pipeline, shipped separately.
