# Per-source query simplification + LoC retry + backplate fit

Closes §7.3 Wikimedia/LoC/IA dead-source problem + the 2-line caption
overflow on the charcoal backplate.

## 1. Per-source query simplification (Path A)

Wikimedia, LoC, and Internet Archive all use literal AND-of-tokens
search semantics. The post-§7.3 Sonnet planner emits long descriptive
queries (10+ tokens) optimised for Pexels — none of those queries
match in archive search engines, because no Commons/LoC/IA document
contains all 10 tokens in its description.

Fix: new `simplify_query(text, max_tokens=4)` helper in
`phase3/sources/base.py`, applied inside each archive source's `search()`.
Pexels still gets the full long query. Deterministic stop-list (no API calls).

Stop-list categories: visual/medium descriptors (sepia, vintage, portrait,
photograph...), era hedges (early, late, mid, century, 1900s decade
words), generic role/wear words (uniform, fez, mustache, bearded...),
and English function words.

Sandbox-verified transforms:

| Before | After |
|---|---|
| Jafar al-Askari Iraqi Ottoman military officer sepia portrait early 1900s uniform | Jafar al-Askari Iraqi Ottoman |
| Sultan Abdulhamid II Ottoman ruler bearded fez official portrait sepia | Sultan Abdulhamid II Ottoman |
| Mosul Iraq Tigris river city 1904 1900s sepia historical photo stone buildings Ottoman | Mosul Iraq Tigris river |
| Constantinople Istanbul 1900s Bosphorus cityscape Ottoman historical photograph sepia panorama | Constantinople Istanbul Bosphorus Ottoman |

## 2. Wikimedia exclusions dropped

`-diagram -anatomy -chart -schematic` was silently rejecting valid hits
whose description happened to mention those words. `filetype:bitmap`
alone keeps SVG diagrams out.

## 3. LoC retry + bumped timeout

LoC was the only source with timeouts in your log (7/26). Bumped from
20s → 30s and added 1 retry. Most LoC timeouts resolve on retry.

## 4. Backplate fits 2-line captions

Was `y=ih*0.85:h=ih*0.12` (130 px at 1080p) — too short for two 98-px caption lines.
Now `y=ih*0.83:h=ih*0.15` (162 px) — covers two lines with breathing room.

## Files

| Path | Change |
|---|---|
| `phase3/sources/base.py` | Add `simplify_query()` + stop-list |
| `phase3/sources/wikimedia.py` | Call simplify, drop exclusions |
| `phase3/sources/loc.py` | Call simplify, 30s timeout + retry |
| `phase3/sources/internet_archive.py` | Call simplify |
| `phase3/render.py` | Backplate lifted + taller |

## Apply

```bash
!unzip -o /content/per_source_query.zip -d /tmp/psq
!cp /tmp/psq/phase3/sources/*.py /content/phase3/sources/
!cp /tmp/psq/phase3/render.py /content/phase3/
!find /content -name __pycache__ -exec rm -rf {} + 2>/dev/null
```

No re-plan needed.

## Expected behaviour

- Wikimedia/LoC/IA should now return non-zero candidates for shots with
  named historical entities (Jafar al-Askari, Sultan Abdulhamid II,
  Mosul, Constantinople).
- Pexels keeps getting the full long query — its caption-matching
  benefits from the descriptors.
- Vision scorer ranks all sources together; best per shot wins. Portrait
  shots still gated by the `MIN_KEEP_SUBJECT_PORTRAIT = 2` floor from
  the §7.4 patch.

## If still no archive hits

Some Sonnet queries don't start with a real named entity — e.g.
shot 7's "Arab nationalist movement officers gathering..." → simplified
to "Arab nationalist movement officers", still vague. Those shots will
remain Pexels-only. That's expected behaviour, not a bug.
