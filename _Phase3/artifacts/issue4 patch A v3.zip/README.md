# Issue 4 patch A v3 — title card + caption rendering

## What this fixes

From the screenshots:

- **Title card** was too quiet for an opening. Now supports book-cover
  full-frame background with aged-gold title and no hairlines; cream
  fallback preserved.
- **Captions appeared as one tiny line** spanning most of the frame.
  Three independent reasons:
  1. Font was small for a documentary (4.2 % of frame height).
  2. WrapStyle was 0 with 80 px margins, so libass never broke long
     captions into two lines.
  3. Consecutive caption events were only 0.1 s apart, so when shots
     changed visuals the captions appeared to run into each other.

## Changes in this version

### Caption rendering (`render.py:_write_captions`)

| Aspect | Before | After |
|---|---|---|
| Font size | 4.2 % of height (~45 px) | 5.0 % (~54 px) |
| Wrap style | WrapStyle 0 + 80 px margins | WrapStyle 2 + 18 % margins |
| Line breaking | None — long captions render as one line | Hard `\N` break inserted after the 8th word, preferring punctuation |
| Inter-event gap | 0.05 s each side (0.10 s total) | 0.15 s each side (0.30 s total) |
| Minimum visible | none (short shots → no caption) | 0.6 s floor centered in the shot |

### Title card (`typography.py`)

- New `GOLD_AGED` color (`#C8A24A`).
- New `TypographySpec.cover_image` and `accent_color` fields.
- `_render_title_card` split into cover-mode and cream-mode variants.
  Cover-mode composites a full-frame cover photo with a darkening
  gradient and aged-gold title; cream-mode is the legacy design.
- `SIZES["title_main"]` bumped 0.085 → 0.110 (about 30 % larger).
- `SIZES["title_sub"]` bumped 0.030 → 0.040.

### Plumbing

- `RenderConfig.book_cover: Path | None` for callers to pass a cover.
- `prebuild_assets.py --book-cover PATH` copies into the dossier as
  `overrides/book_cover.<ext>` and records `book.cover_path`.
- `render_plan.py --book-cover PATH` explicit flag.
- `render_plan.py` also reads `book.cover_path` from `decisions.json`
  when `--review-dir` is set.

## How to apply

Drop the four `.py` files in this bundle over their counterparts in
`_Phase3/`.

In Colab, cell 0 clones the repo into `/content/`, so apply the files
*after* cell 0 runs.  Either push the patched files to your repo so
cell 0 picks them up natively, or upload them and `cp` over the cloned
versions after cell 0.

## How to verify before rendering

```bash
python verify_title_card.py        # general patch self-check
python diagnose_issue4.py --review-dir output/review/   # is everything in place?
python diagnose_captions.py --plan output/al_askari_plan_v2.json   # inspect actual ASS events
```

The third one is the most useful one if the captions still look
wrong: it calls `_write_captions` directly against your real plan
and prints the resulting ASS dialogue events with their gap from the
previous event. If you see gaps of ~0.30 s and text containing `\N`,
the patch is live.

## How to use the cover

```bash
python prebuild_assets.py \
    --plan output/al_askari_plan_v2.json \
    --script samples/al_askari_script.txt \
    --book-title "مذكرات جعفر العسكري" \
    --character-name "Jafar al-Askari" \
    --review-dir output/review/ \
    --character-portrait my_jafar.jpg \
    --book-cover my_book_cover.jpg

python render_plan.py \
    --plan output/al_askari_plan_v2.json \
    --audio output/al_askari_audio.mp3 \
    --review-dir output/review/ \
    --output output/final_cut.mp4
```

Cover image should be ≥ 3072 × 1728 for crisp rendering.  The cover
is shown static (no Ken-Burns motion), so 1920 × 1080 is the floor.

## What's still pending (issue 4 patch B)

- Caption **backplate** — semi-transparent charcoal bar behind the
  subtitles, with cream text instead of white-on-outline. Touches
  `_mux_final` (FFmpeg pipeline). Shipping separately so this one
  can be validated in isolation.
