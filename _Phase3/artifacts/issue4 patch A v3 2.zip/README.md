# Issue 4 patch A v3.2 — title card + caption rendering

## What changed from v3.1

1. **Escape-order bug fixed.** v3.0 and v3.1 emitted `\\N` (double
   backslash + N) in the ASS file, which libass renders as a literal
   backslash on screen — producing the `\،` artifact at every wrap
   point. v3.2 calls `_escape_ass()` **before** `_wrap_caption()`, so
   the file contains a single `\N` (the correct ASS line-break
   sequence) and libass renders a clean two-line caption.

2. **`--no-captions` help text** improved. The flag already existed
   end-to-end (`render_plan.py --no-captions` skips the burn-in pass
   entirely). The help text now explains when to use it: when the
   audio narration is sufficient on its own.

3. **Diagnostics extended.** `diagnose_issue4.py` now detects the
   escape-order bug specifically:
       ✗ caption escape order is _wrap_caption → _escape_ass (v3.0/3.1 bug)
   And `diagnose_captions.py` counts `\\N` occurrences and flags them.

## Quick start

```bash
# Apply patch
cp render.py            _Phase3/phase3/render.py
cp typography.py        _Phase3/phase3/typography.py
cp prebuild_assets.py   _Phase3/prebuild_assets.py
cp render_plan.py       _Phase3/render_plan.py

# Verify
cd _Phase3
python diagnose_issue4.py --review-dir output/review/
python diagnose_captions.py --plan output/al_askari_plan_v2.json

# Render with captions
python render_plan.py \
    --plan output/al_askari_plan_v2.json \
    --audio output/al_askari_audio.mp3 \
    --review-dir output/review/ \
    --output output/final_cut.mp4

# Render without captions (audio-only)
python render_plan.py \
    --plan output/al_askari_plan_v2.json \
    --audio output/al_askari_audio.mp3 \
    --review-dir output/review/ \
    --no-captions \
    --output output/final_cut_nocaps.mp4
```

## Verification — what good output looks like

`diagnose_issue4.py` should show **all** of these:

    ✓ caption GAP = 0.15
    ✓ caption MIN_VISIBLE = 0.6
    ✓ ASS header has WrapStyle: 2
    ✓ _wrap_caption() helper present
    ✓ caption escape order is _escape_ass → _wrap_caption  ← v3.2 check
    ✓ caption font size at 5.0% of frame height

`diagnose_captions.py` should end with:

    Wrapped events: 15/15 have an explicit \N break
    ✓ Gaps ~0.30s AND captions wrapped cleanly — v3.2 PATCH IS LIVE.

If you see this instead:

    ⚠ 15 event(s) have \\N (double backslash) — libass will render a literal '\' on screen.
    ✗ Captions wrap, but \N is double-escaped — v3.0/3.1 bug.

your render.py is from v3.0 or v3.1. Replace it with the one in this bundle.

## Full change ledger (versus the original v3 patch)

| Aspect | Original | v3.2 |
|---|---|---|
| Inter-event caption gap | 0.10 s | 0.30 s |
| Minimum visible time | none | 0.6 s |
| Caption font size at 1080p | 45 px (4.2%) | 54 px (5.0%) |
| WrapStyle in ASS header | 0 | 2 |
| Horizontal caption margins | 80 px | ~345 px (18% of width) |
| Line breaking | none | `\N` inserted after ≈8th word |
| Escape order | _wrap → _escape (bug) | _escape → _wrap (correct) |
| Title size (cream mode) | 0.085 of height | 0.110 of height |
| Title subtitle size | 0.030 | 0.040 |
| Title card with cover | not supported | book cover + aged-gold title, no hairlines |
| Caption disable | flag existed, undocumented | `--no-captions` with help text |

## What's still pending (issue 4 patch B)

Caption backplate: charcoal-bar + cream-text aesthetic. Touches the
FFmpeg mux pipeline, shipped separately.
