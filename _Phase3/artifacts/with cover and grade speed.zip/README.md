# Fix 2 — closing title_card with-cover overflow + 2× render time

Two independent regressions, one zip.

## Fix 1: `_render_title_card_with_cover` text overflow (all 3 families)

**Root cause.** The previous auto-shrink patch only touched the cream/
dark/paper variants of `title_card`. The `with_cover` variant (used by
the closing card in your b3d render) was untouched, and it had two
latent bugs:

1. Width budget computed *after* text measurement, so the auto-shrink
   helper never saw the narrow right-column budget.
2. Subtitle drawn as a single line — when text exceeded the column,
   Pillow's `draw.text` overflowed off-frame instead of wrapping.

**Fix.** In each family's `_render_title_card_with_cover`:
- Compute the real text-region width *before* measuring (uses `align`
  + `_resize_cover_to_contain` like the original layout did, just earlier).
- Apply 10% inner margin to the spare region (matches `MARGINS["horizontal_pct"]`).
- Run `_fit_text_to_width` on the headline against that budget.
- Run `_wrap_by_width` on the subtitle, draw line-by-line at
  `LINE_HEIGHT_MULT × sub_size`.

Sandbox reproduction with the documented offender (1200×1800 cover,
contain+left, full credit subtitle) — see `previews/title_card_with_cover_fixed.png`.
Title sits clean in the right region; subtitle wraps onto 2 lines, no
off-frame bleed.

## Fix 2: 2× render time

**Measured cause.** Benchmark on a 10s 1280×720 test clip (encode time
vs ungraded):

    preset      time      vs ungraded
    ungraded    7.84s     100%
    warm       17.39s     222%   ← was using colorbalance
    cool       16.63s     212%   ← was using colorbalance
    neutral     7.74s      99%
    bw          7.30s      93%

The `colorbalance` filter does per-tonal-range RGB pushes; it's
applied per-pixel × 3 channels × 3 tonal ranges and is the slowest
common color filter in libavfilter. Doubled total encode time on a
6.5-min 1080p video.

**Fix.** Replace `colorbalance` with a single `curves` filter (per-
channel control points). Visually equivalent for the warm/cool intent
(see `previews/grade_old_vs_new.png` — slight reduction in warm
saturation, cool nearly identical), but ~2× faster.

New benchmarks:

    preset      time      vs ungraded
    ungraded    7.50s     100%
    warm        9.06s     121%   ← was 222%
    cool        9.16s     122%   ← was 212%

On your 6.5-min render: estimated ~6–8 minutes saved per warm/cool
render vs the previous patch.

Neutral and bw are unchanged (already cheap).

## Files

| File | Action |
|------|--------|
| `phase3/typography_a.py` | Replace. with_cover fix. |
| `phase3/typography_b.py` | Replace. with_cover fix. |
| `phase3/typography_c.py` | Replace. with_cover fix. |
| `phase3/typography_common.py` | Replace. (unchanged from autoshrink patch — same SIZES + `_fit_text_to_width` from the previous fix.) |
| `phase3/render.py` | Replace. New `GRADE_PRESETS` for warm/cool. |

## Apply

```bash
!unzip -o /content/with_cover_and_grade_speed.zip -d /tmp/fix2
!cp /tmp/fix2/phase3/*.py /content/phase3/
!find /content/phase3 -name __pycache__ -exec rm -rf {} + 2>/dev/null; echo done

!python diagnose_grade.py   # confirms new filter strings compile
!python verify_title_card.py --book-cover my_book.jpg
```

Then render — should complete in roughly the original (pre-grade) time.
