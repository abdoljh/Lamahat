# Issue 1 — Color philosophy / `--grade` patch

**Closes**: Phase3.md §15.1 (the only remaining Tier-1 item).
**Touches**: `phase3/render.py`, `render_plan.py`.
**Net diff**: ~60 added lines, 0 removed.

## What ships

A `--grade {warm,cool,neutral,bw}` flag on `render_plan.py`, plumbed
through `RenderConfig.grade` into a single FFmpeg filter string applied
at the final mux stage **before** the subtitle burn-in. Default is
`warm` (pronounced cinematic look).

Per-section variation is intentionally not implemented (Phase3.md
flagged it as a stretch goal). Once you decide a `grade_map.json` is
worth adding, it slots in here without re-planning since shots already
carry `section_id`.

## The four presets

| Preset    | Look                                                                                                     | When to use                                          |
| --------- | -------------------------------------------------------------------------------------------------------- | ---------------------------------------------------- |
| `warm`    | Pronounced: contrast +8%, sat +5%, teal-shadow / orange-highlight colorbalance, `increase_contrast` curve | Default. Memoirs, biographies, archive-heavy decks   |
| `cool`    | Editorial: contrast +5%, sat −5%, blue-shadow / warm-highlight                                            | War, somber political, investigative                 |
| `neutral` | Gentle S-curve only (contrast +3%), no color cast                                                        | Source imagery already graded; photographic books    |
| `bw`      | Full desaturation + 10% contrast bump                                                                    | Documentary mono, historical figures                 |

Each preset is **a single FFmpeg filter string** (per your call).
Composition is `eq` (overall contrast/saturation) → `colorbalance`
(per-tonal-range RGB pushes) → optional `curves` (S-curve).

Round-trip safe — every transform is multiplicative/additive in the
narrow range FFmpeg accepts. No clipping observed in sandbox tests.

## Why grade-then-subs, not subs-then-grade

`_mux_final` builds `vf_parts` as `[grade, ass=...]`. libass overlays
captions onto the **already-graded** frame, so caption white stays
clean white regardless of preset. If grading ran *after* subs, the
caption text itself would be tinted by `bw` (grey captions) or shifted
by `warm` (slight orange on white). This matches the order a real
colorist uses.

## CLI

```bash
python render_plan.py \
    --plan         output/al_askari_plan_v2.json \
    --audio        output/al_askari_audio.mp3 \
    --review-dir   output/review/ \
    --book-cover-fit contain \
    --typography-family C \
    --grade        warm \             # ← new
    --no-captions \
    --output       output/final_cut_C_warm.mp4
```

Precedence: **CLI flag > default** (no dossier path per your call;
matches the simplest shape from issue 4).

## Files in this zip

| File                          | Action                                  |
| ----------------------------- | --------------------------------------- |
| `phase3/render.py`            | Replace. Adds `GRADE_PRESETS`, `DEFAULT_GRADE`, `grade` param in `_mux_final`, `grade` field in `RenderConfig`. |
| `render_plan.py`              | Replace. Adds `--grade` argparse flag and wires it into `RenderConfig`. |
| `diagnose_grade.py`           | New. Drop at repo root. ~10 s diagnostic. |
| `grade_previews/`             | Synthesised before/after frames for visual review. Not part of the runtime. |

## How to apply (Colab)

```python
# After cell 0 (which clones the repo into /content/):
!unzip -o /content/issue1_patch.zip -d /tmp/issue1
!cp /tmp/issue1/phase3/render.py  /content/phase3/render.py
!cp /tmp/issue1/render_plan.py    /content/render_plan.py
!cp /tmp/issue1/diagnose_grade.py /content/diagnose_grade.py

# Force-clear .pyc cache (caught us in issue 4):
!find /content/phase3 -name "__pycache__" -exec rm -rf {} + 2>/dev/null; echo done
```

## Verification recipe

```bash
cd /content
python diagnose_grade.py                       # ~10 s — all 5 checks must pass
python verify_title_card.py --book-cover my_book.jpg
python diagnose_issue4.py --review-dir output/review/
python diagnose_captions.py --plan output/al_askari_plan_v2.json
```

Then a smoke render (drop `--no-captions` for a 30-second clip if you
want to skim faster — but full plan + `--no-captions` is what you ran
last time, so it's apples-to-apples):

```bash
!python render_plan.py \
  --plan output/al_askari_plan_v2.json \
  --audio output/al_askari_audio.mp3 \
  --review-dir output/review/ \
  --book-cover-fit contain \
  --typography-family C \
  --grade warm \
  --no-captions \
  --output output/final_cut_C_warm.mp4
```

Render-time impact: one extra FFmpeg filter in an existing video
pass. **No additional encode passes, no measurable slowdown** (the
filter chain already re-encodes for subtitle burn-in).

## Compatibility

| Concern                                | Status                                                                                              |
| -------------------------------------- | --------------------------------------------------------------------------------------------------- |
| Hard caps in `plan.py` (CLAUDE.md §6)  | Untouched.                                                                                          |
| Typography family registries           | Untouched. All 3 families work with all 4 grades.                                                   |
| Caption escape order / wrap            | Untouched — grade runs upstream of the subs filter.                                                 |
| Cover-fit precedence (CLI > dossier)   | `--grade` adds CLI only; if you ever want dossier support, mirror the issue-4 pattern in render_plan.py around line 280. |
| `--no-captions` path                   | Works — `vf_parts` collapses to just the grade filter, mux still re-encodes (required for grading). |
| Audio-only / ungraded escape hatch     | Not exposed via CLI on purpose, but you can pass `grade=None` to `RenderConfig` programmatically.   |

## Visual preview

The `grade_previews/` folder shows what each preset does to a
synthesised archive-style frame and a portrait-style frame. These were
generated in the sandbox with the actual filter strings from
`GRADE_PRESETS`, so they're representative — not stylised mocks.

Open `compare_archive.png` and `compare_portrait.png` to see all five
options stacked vertically (source on top, then warm / cool / neutral
/ bw).

## What I would do next

After your eye on the previews:

1. **If `warm` lands too strong**: swap `curves=preset=increase_contrast`
   for `curves=preset=medium_contrast` in the warm preset (one-token
   change).
2. **If you want section-aware grading**: I have `section_id` per shot
   from the planner, so a `grade_map.json` keyed on section ID can drop
   in. ~30 LoC in `_mux_final` (would need to render each section
   separately and concat).
3. **If `warm` is the keeper**: nothing to do — it's already the default.
