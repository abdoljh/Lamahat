# Phase 3 v2 — Foundation: Align + Plan

This drop adds two new modules to `phase3/` and revises `phase3_run.py`.
Nothing in the existing v1 render path changes — `--keywords-only`,
`--dry-run`, and full rendering all work exactly as before.

What's new:

- **`phase3/align.py`** — word-level forced alignment of TTS audio
  against the known script.  WhisperX preferred, Whisper second,
  interpolation fallback always available.
- **`phase3/plan.py`** — single-call AI shot planner.  Claude Sonnet 4.6
  receives the script + word timings + book context and returns a
  complete JSON shot list (60–80 shots for a 4-minute video) with
  per-shot visual type, motion, search query, and optional Arabic
  typography text.
- **`phase3_run.py`** — adds `--align-only` and `--plan-only` modes for
  inspecting the v2 pipeline before committing to rendering.

## Why this is the right structural change

Three problems in the v1 design that this fixes:

1.  **The visual unit was wrong.**  v1 has ~8 sections × 3 images = 24
    Ken-Burns clips for a 4-minute video.  Modern long-form documentary
    cuts every 3–5 s, so a 4-minute video wants 60–80 shots.  The
    "shot" is now the atom; sections are just grouping metadata.

2.  **Cuts were decoupled from speech.**  v1 estimates section duration
    from character count and hopes for the best.  v2 measures *exactly*
    when each Arabic word is spoken via WhisperX phoneme alignment
    (<100 ms accuracy).  Shot boundaries always fall on word
    boundaries — never mid-syllable.

3.  **There was no plan to inspect.**  v1 made all creative decisions
    inside the render loop.  v2 produces a JSON document first.  You
    look at the plan, decide if the video will be good, and only then
    render.

## How to use the new modes

### `--align-only` — inspect word timings

```bash
python phase3_run.py \
    --script script.txt \
    --audio audio.mp3 \
    --align-only \
    --save-alignment output/word_timings.json
```

Prints the first 30 word timings as a sanity check and writes the full
list to `word_timings.json`.  Backend auto-selection: WhisperX →
Whisper → interpolation.  Force a specific backend with
`--align-backend whisperx|whisper|interpolated`.

When WhisperX/Whisper aren't installed, you'll get `source: "interpolated"`
in the output, which distributes the total duration by character count.
That's enough to test the planner end-to-end without installing the
ASR stack.

### `--plan-only` — generate the JSON shot plan

```bash
python phase3_run.py \
    --script script.txt \
    --audio audio.mp3 \
    --book-title "مذكرات جعفر العسكري" \
    --character-name "Jafar al-Askari" \
    --plan-only \
    --save-plan output/shot_plan.json
```

Runs alignment, then one Sonnet 4.6 call (~$0.05–0.15), then prints a
shot-by-shot summary and writes the plan to disk.

Example summary output:

```
Plan: 64 shots, 218.4s total
────────────────────────────────────────────────────────────────────────
Visuals: location:18  archive:16  typography:14  portrait:8  broll:5  title_card:1  section_mark:2
────────────────────────────────────────────────────────────────────────
   1. [  opening]   0.00-  4.20s ( 4.2s) title_card     static_hold
   2. [  opening]   4.20-  7.50s ( 3.3s) archive        slow_push     Baghdad 1920 Ottoman street photo
   3. [  opening]   7.50- 10.85s ( 3.4s) typography     static_hold   "في زمن كانت الإمبراطورية تترنح"
   ...
```

The JSON file is the actual contract with the (next-session) renderer.
Inspect it directly to debug:

```bash
jq '.[] | {start, visual, search_query, typography_text}' output/shot_plan.json
```

## Installing WhisperX (when you're ready)

WhisperX is optional but unlocks the real value.  The interpolation
fallback exists so you can develop without it.

```bash
# CPU-only install (sufficient for 3–5 min audio)
pip install whisperx
```

On first run, WhisperX downloads:

- Whisper `small` model (~470 MB)
- Arabic wav2vec2 alignment model `jonatasgrosman/wav2vec2-large-xlsr-53-arabic`
  (~1.2 GB)

Total disk: ~1.7 GB.  RAM at runtime: ~600 MB.  This is fine locally
and on most cloud runners but **may exceed Streamlit Cloud's 1 GB
limit** — for the deployed app we'll likely keep `--align-backend
interpolated` until we move off the free tier.

## File layout after this change

```
phase3_run.py           # revised: adds --align-only / --plan-only
phase3/
  __init__.py           # unchanged
  parser.py             # unchanged
  keywords.py           # unchanged (still used by v1 path)
  wikimedia.py          # unchanged
  pexels.py             # unchanged
  effects.py            # unchanged
  compositor.py         # unchanged
  subtitler.py          # unchanged
  align.py              # NEW — forced alignment
  plan.py               # NEW — shot planner
```

The v1 render uses neither `align.py` nor `plan.py`.  The next session
adds a v2 renderer that consumes the shot plan JSON.

## What comes next (next session's work)

Three pieces in priority order:

1.  **`sources/__init__.py`** — multi-source image fetcher with disk
    cache.  Wikimedia → Library of Congress → Internet Archive →
    Pexels in priority order.  Each cached under
    `~/.cache/lamahat/images/{query_hash}/`.

2.  **`typography.py`** — Pillow card renderer for shots whose
    `visual="typography"`.  Templates: `pull_quote`, `name_reveal`,
    `date_stamp`, `chapter_heading`.  Arabic shaping via
    `arabic_reshaper` + `python-bidi`, font Amiri, gradient/grain
    backgrounds for designer-grade quality.

3.  **`render.py`** — new shot-level compositor that consumes the
    plan JSON.  Per-shot FFmpeg pipeline (image → motion → optional
    caption overlay), then a single concat (cuts, not crossfades, by
    default — xfades only at section boundaries).  Replaces v1's
    `compositor.py` only when called via the new path; v1 still works.

4.  Wire `phase3_run.py --output …` to use the new renderer when a
    plan JSON exists, falling back to the v1 path otherwise.

## Validation done in this session

`test_smoke.py` (run with `python test_smoke.py`) verifies:

- Arabic tokenisation
- Interpolation fallback
- Section bucketing
- Shot post-processing (word-boundary snapping, caption filling,
  section assignment, over-long shot splitting, gap/overlap removal)
- JSON round-trip
- Plan summary printing

All passing.  These are unit tests; the real test will be eyeballing
the JSON plan Sonnet produces against your actual scripts.
