"""
Phase 3 — Shot planner.

Takes:
  - The Arabic script (parsed sections)
  - Word-level timings from align.py
  - Book context (title, character, genre)

Produces:
  - A list of Shot records that fully specify the video, shot by shot.

The compositor (next session's work) executes shots without making any
creative decisions — all decisions live in the plan.

Design principles
-----------------
* ONE Claude call per video.  Sonnet 4.6 is the right model: it has the
  reasoning depth to make varied creative choices across 60–80 shots,
  and at ~$0.10/video the cost is negligible.
* The plan is JSON.  Inspectable, diffable, regeneratable.  When the
  output video is disappointing you debug the plan first, the renderer
  second.
* Word timings are the truth.  Shot boundaries always fall on word
  boundaries — never mid-word — so cuts feel intentional.
* Variety is mandated by the prompt.  We tell Sonnet explicitly that
  shots over 6 s without overlay text are forbidden in long-form, and
  that typography cards must account for ~25–35 % of shots.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Literal

from .align import WordTiming, assign_words_to_sections, tokenize_script
from .parser import ScriptSection

log = logging.getLogger(__name__)


# ── Shot type taxonomy ───────────────────────────────────────────────────── #

ShotVisual = Literal[
    "portrait",       # primary subject's face — use static_hold or slow_push
    "location",       # places, landscapes, architecture
    "object",         # documents, weapons, artefacts, books
    "archive",        # period photographs, newspapers, maps
    "broll",          # generic atmospheric footage (Pexels)
    "typography",     # full-screen Arabic text card (no image)
    "title_card",     # opens the video: book title + author
    "section_mark",   # short interstitial naming the section
]

ShotMotion = Literal[
    "static_hold",    # no camera move (best for portraits, typography)
    "slow_push",      # 1.00 → 1.08 over the shot
    "fast_push",      # 1.00 → 1.20 (emphasis, 1.5–3 s shots)
    "slow_pull",      # 1.08 → 1.00 (reveal)
    "pan_left",       # horizontal pan
    "pan_right",
    "ken_burns",      # mixed zoom + pan (only for long landscapes)
]

TypographyTemplate = Literal[
    "pull_quote",     # large centred quote with quotation marks
    "name_reveal",    # "{character_name} —" with a date underneath
    "date_stamp",     # full-screen year/date in massive serif
    "chapter_heading", # section interstitial
]


@dataclass
class Shot:
    """A single shot in the video.  All time is in seconds from t=0."""

    # Timing
    start: float
    end: float

    # Visual selection
    visual: ShotVisual
    search_query: str = ""              # English query for the image source
    source_hint: str = "auto"           # "wikimedia" | "loc" | "pexels" | "auto"

    # Motion
    motion: ShotMotion = "slow_push"
    motion_intensity: float = 1.0        # 0.5 = subtle, 1.5 = exaggerated

    # Typography (only for visual="typography")
    typography_template: TypographyTemplate | None = None
    typography_text: str = ""            # the Arabic text to display

    # Caption overlay (Arabic words spoken during this shot)
    caption_text: str = ""               # auto-filled by build_shot_plan
    show_caption: bool = True            # off for title_card / hero moments

    # Optional creative note from the planner (free-form, for debugging)
    note: str = ""

    # Section this shot belongs to (auto-filled)
    section_id: str = ""

    @property
    def duration(self) -> float:
        return max(0.0, self.end - self.start)


# ── Prompt construction ─────────────────────────────────────────────────── #

_SYSTEM_PROMPT = """\
You are a documentary video editor planning the visual flow of an Arabic \
book-summary video.  You will receive the script, word-by-word audio \
timings, and book context.  Your job is to output a JSON shot list that \
makes the video genuinely cinematic.

Hard rules
----------
1.  Output JSON only.  No markdown, no commentary.
2.  Shot boundaries must fall on word boundaries — start/end times must \
    match one of the word timings provided.
3.  Shots must be between 1.5 s and 6.0 s.  Title card and section \
    mark shots may go up to 5 s.  Shots over 6 s are FORBIDDEN.
4.  The shot list must cover the entire script with no gaps and no \
    overlaps.  shot[i].end == shot[i+1].start.
5.  Each shot has exactly one `visual` type.  Use the full vocabulary — \
    avoid stacking 5 "location" shots in a row.  Aim for 25–35 % \
    typography shots, distributed across the video.
6.  Search queries are in English, specific, and named.  Bad: "horse". \
    Good: "Arab cavalry Faisal 1916".  For people, use full names.
7.  Typography shots have `typography_text` filled with Arabic text \
    taken (or lightly condensed) from the script.  No translation, no \
    invention.  Pull quotes should be the most resonant lines in the \
    script — the lines that would make someone stop scrolling.
8.  Motion choice matters:
    - `static_hold` for portraits and typography (let them land)
    - `slow_push` for most B-roll
    - `fast_push` only on emphasis beats (rare, ≤3 per video)
    - `pan_*` for landscapes and wide compositions
9.  Always open with a `title_card` (3–5 s) showing the book title.
10. Optionally use `section_mark` shots between sections (1.5–2.5 s).

Output schema
-------------
{
  "shots": [
    {
      "start": float,
      "end": float,
      "visual": "portrait" | "location" | "object" | "archive" | \
                "broll" | "typography" | "title_card" | "section_mark",
      "search_query": "English search terms, specific and named",
      "motion": "static_hold" | "slow_push" | "fast_push" | "slow_pull" |\
                "pan_left" | "pan_right" | "ken_burns",
      "motion_intensity": 1.0,
      "typography_template": null | "pull_quote" | "name_reveal" | \
                             "date_stamp" | "chapter_heading",
      "typography_text": "Arabic text or empty string",
      "show_caption": true | false,
      "note": "one-line creative reasoning, optional"
    }
  ]
}
"""

_USER_PROMPT_TMPL = """\
Book title: {book_title}
Main character / subject: {character_name}
Genre: {genre}
Total audio duration: {total_duration:.1f} seconds

Script sections (with word-level timings):
{sections_with_timings}

Notes for the planner:
- Open with a 4-second title_card showing the book title.
- Aim for {target_shots} shots total (≈ {avg_duration:.1f} s average).
- Typography shots: choose the most emotionally resonant lines from the \
  script — quotes that would stand alone as social-media graphics.
- For portrait searches of "{character_name}", use the name in English \
  (e.g. "Jafar al-Askari portrait") plus any known historical context \
  from the script.
- For location searches, ground them: "Baghdad 1920 historical photo" \
  beats "Iraq".
- Avoid stacking same-visual shots: vary portrait → location → typography\
  → archive → location, etc.

Return JSON only.
"""


def _format_sections_for_prompt(
    sections: list[ScriptSection],
    section_word_map: dict[str, tuple[float, float, list[WordTiming]]],
) -> str:
    """
    Build a compact textual representation of each section with its
    word-level timings, suitable for inclusion in the planner prompt.

    Each section is rendered as:
        [section_id]  T=12.30–37.85s  (62 words)
        Arabic text body...
        Word timings: word@12.30 word@12.65 word@13.10 ...
    """
    lines: list[str] = []
    for section in sections:
        info = section_word_map.get(section.section_id)
        if not info:
            continue
        sec_start, sec_end, words = info
        lines.append(
            f"\n[{section.section_id}]  T={sec_start:.2f}–{sec_end:.2f}s  "
            f"({len(words)} words)"
        )
        # Cap section text at ~600 chars for prompt size control
        text_excerpt = section.text.strip()
        if len(text_excerpt) > 600:
            text_excerpt = text_excerpt[:600] + "…"
        lines.append(text_excerpt)
        # Word timings: include every word so the planner can pick exact
        # cut points.  Compact format: "word@1.23".
        timing_line = " ".join(f"{w.word}@{w.start:.2f}" for w in words)
        lines.append(f"WORDS: {timing_line}")

    return "\n".join(lines)


# ── Public API ───────────────────────────────────────────────────────────── #

def build_shot_plan(
    sections: list[ScriptSection],
    word_timings: list[WordTiming],
    *,
    book_title: str,
    character_name: str,
    genre: str,
    total_duration_sec: float,
    anthropic_api_key: str,
    target_shot_duration: float = 3.5,
    model: str = "claude-sonnet-4-6",
) -> list[Shot]:
    """
    Generate a complete shot plan in a single Claude call.

    Parameters
    ----------
    sections             From parser.parse_sections().
    word_timings         From align.align().
    book_title           For prompt context and title card.
    character_name       For portrait queries and name_reveal cards.
    genre                Steers visual choices ("history" prefers archive
                         photographs; "philosophy" prefers typography).
    total_duration_sec   Authoritative total duration.
    anthropic_api_key    Required.
    target_shot_duration Desired average shot length (used to size the
                         expected shot count in the prompt).
    model                Sonnet 4.6 by default.  Override for testing.
    """
    from anthropic import Anthropic

    section_word_map = assign_words_to_sections(word_timings, sections)
    target_shots = max(8, int(total_duration_sec / target_shot_duration))

    user_prompt = _USER_PROMPT_TMPL.format(
        book_title=book_title or "unknown",
        character_name=character_name or "not specified",
        genre=genre,
        total_duration=total_duration_sec,
        sections_with_timings=_format_sections_for_prompt(
            sections, section_word_map),
        target_shots=target_shots,
        avg_duration=target_shot_duration,
    )

    log.info("Calling %s for shot plan (target=%d shots, %.1fs avg)",
             model, target_shots, target_shot_duration)

    client = Anthropic(api_key=anthropic_api_key)
    response = client.messages.create(
        model=model,
        max_tokens=8000,
        system=_SYSTEM_PROMPT,
        messages=[{"role": "user", "content": user_prompt}],
    )
    raw = response.content[0].text.strip()
    raw = (raw
           .removeprefix("```json")
           .removeprefix("```")
           .removesuffix("```")
           .strip())

    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        log.error("Planner returned invalid JSON: %s", exc)
        log.debug("Raw response:\n%s", raw)
        raise ValueError(f"Shot planner returned invalid JSON: {exc}") from exc

    shots_data = data.get("shots", [])
    if not shots_data:
        raise ValueError("Shot planner returned no shots")

    shots = [_shot_from_dict(s) for s in shots_data]

    # Post-process: snap to word boundaries, fill captions, assign sections
    shots = _snap_to_word_boundaries(shots, word_timings)
    shots = _fill_captions(shots, word_timings)
    shots = _assign_sections(shots, section_word_map)
    shots = _validate_plan(shots, total_duration_sec)

    log.info("Plan produced: %d shots", len(shots))
    return shots


# ── Shot construction & post-processing ─────────────────────────────────── #

def _shot_from_dict(d: dict) -> Shot:
    """Build a Shot from the planner's JSON dict, with defaulting."""
    return Shot(
        start=float(d.get("start", 0.0)),
        end=float(d.get("end", 0.0)),
        visual=d.get("visual", "broll"),
        search_query=d.get("search_query", "") or "",
        source_hint=d.get("source_hint", "auto") or "auto",
        motion=d.get("motion", "slow_push"),
        motion_intensity=float(d.get("motion_intensity", 1.0)),
        typography_template=d.get("typography_template") or None,
        typography_text=d.get("typography_text", "") or "",
        show_caption=bool(d.get("show_caption", True)),
        note=d.get("note", "") or "",
    )


def _snap_to_word_boundaries(
    shots: list[Shot],
    word_timings: list[WordTiming],
) -> list[Shot]:
    """
    Snap each shot's start/end to the nearest actual word boundary.
    Prevents cuts mid-syllable when the planner is slightly off.
    """
    if not word_timings:
        return shots

    word_starts = [w.start for w in word_timings]
    word_ends = [w.end for w in word_timings]

    def _snap(t: float, anchors: list[float]) -> float:
        # Linear scan is fine — a few hundred words at most
        return min(anchors, key=lambda a: abs(a - t))

    snapped: list[Shot] = []
    for shot in shots:
        s = _snap(shot.start, word_starts)
        e = _snap(shot.end, word_ends)
        if e <= s:
            e = s + 1.5  # minimum shot duration
        snapped.append(Shot(**{**asdict(shot), "start": s, "end": e}))
    return snapped


def _fill_captions(
    shots: list[Shot],
    word_timings: list[WordTiming],
) -> list[Shot]:
    """Concatenate the Arabic words spoken during each shot into its caption."""
    for shot in shots:
        words_in_shot = [
            w.word for w in word_timings
            if w.start >= shot.start - 0.05 and w.end <= shot.end + 0.05
        ]
        shot.caption_text = " ".join(words_in_shot)
    return shots


def _assign_sections(
    shots: list[Shot],
    section_word_map: dict[str, tuple[float, float, list[WordTiming]]],
) -> list[Shot]:
    """Tag each shot with the section_id whose time range contains it."""
    section_ranges = [(sid, s, e) for sid, (s, e, _) in section_word_map.items()]
    for shot in shots:
        midpoint = (shot.start + shot.end) / 2
        for sid, s, e in section_ranges:
            if s <= midpoint <= e:
                shot.section_id = sid
                break
    return shots


def _validate_plan(shots: list[Shot], total_duration_sec: float) -> list[Shot]:
    """
    Enforce structural invariants on the shot plan.

    - Sort by start time
    - Eliminate overlaps and gaps by snapping consecutive shots together
    - Trim or extend the final shot to cover the full audio
    - Cap any shot >6 s by splitting it
    """
    if not shots:
        return shots

    shots = sorted(shots, key=lambda s: s.start)

    # Stitch into a contiguous timeline
    fixed: list[Shot] = []
    for i, shot in enumerate(shots):
        if fixed:
            # Make this shot's start = previous shot's end
            prev_end = fixed[-1].end
            if shot.start != prev_end:
                shot = Shot(**{**asdict(shot), "start": prev_end})
            if shot.end <= shot.start:
                shot.end = shot.start + 2.0
        fixed.append(shot)

    # Pin the last shot to the audio end
    fixed[-1].end = total_duration_sec

    # Split any over-long shots
    final: list[Shot] = []
    for shot in fixed:
        if shot.duration <= 6.0:
            final.append(shot)
            continue
        # Split into N equal chunks of ≤4 s
        n_pieces = int(shot.duration // 4) + 1
        piece_dur = shot.duration / n_pieces
        for k in range(n_pieces):
            piece = Shot(**asdict(shot))
            piece.start = shot.start + k * piece_dur
            piece.end = shot.start + (k + 1) * piece_dur
            piece.note = (piece.note +
                          f" [auto-split {k + 1}/{n_pieces}]").strip()
            final.append(piece)

    return final


# ── Serialisation ────────────────────────────────────────────────────────── #

def shots_to_json(shots: list[Shot]) -> str:
    """Serialise the plan as pretty JSON for inspection or caching."""
    return json.dumps(
        [asdict(s) for s in shots],
        ensure_ascii=False,
        indent=2,
    )


def shots_from_json(text: str) -> list[Shot]:
    """Deserialise a plan from JSON (round-trip safe with shots_to_json)."""
    data = json.loads(text)
    return [_shot_from_dict(d) for d in data]


def save_plan(shots: list[Shot], path: Path) -> Path:
    """Write the plan to disk; returns the path."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(shots_to_json(shots), encoding="utf-8")
    return path


def load_plan(path: Path) -> list[Shot]:
    """Load a previously-saved plan."""
    return shots_from_json(path.read_text(encoding="utf-8"))


# ── Plan summary printer ─────────────────────────────────────────────────── #

def summarise_plan(shots: list[Shot]) -> str:
    """Human-readable one-line-per-shot summary, for the CLI."""
    if not shots:
        return "(empty plan)"

    lines: list[str] = []
    lines.append(f"Plan: {len(shots)} shots, "
                 f"{sum(s.duration for s in shots):.1f}s total")
    lines.append("─" * 92)

    # Histogram of visual types
    from collections import Counter
    visual_counts = Counter(s.visual for s in shots)
    histogram = "  ".join(f"{v}:{n}" for v, n in visual_counts.most_common())
    lines.append(f"Visuals: {histogram}")
    lines.append("─" * 92)

    for i, shot in enumerate(shots):
        section_tag = f"[{shot.section_id:>9}]" if shot.section_id else "[         ]"
        timing = f"{shot.start:6.2f}-{shot.end:6.2f}s"
        dur = f"({shot.duration:4.1f}s)"
        kind = f"{shot.visual:<14}"
        motion = f"{shot.motion:<12}"

        if shot.visual == "typography":
            extra = f'"{shot.typography_text[:50]}"'
        else:
            extra = shot.search_query[:60]

        lines.append(
            f"  {i+1:>3}. {section_tag} {timing} {dur} {kind} {motion}  {extra}"
        )
    return "\n".join(lines)
