# Phase 3 v2 — Patch 2: Based on the first real Sonnet output

The al-Askari plan you generated revealed three issues — none of them
in Sonnet's creative work, all in our post-processing and prompt
constraints.  This patch addresses each.

## What the first plan actually showed

Stats from your `al_askari_plan.json`:

- **Total shots in final plan: 106** (after our post-processing)
- **Original Sonnet shots: 67** (estimated from auto-split count)
- **Auto-split shots: 78 / 106 (74 %)** ← the problem
- **Plan duration: 391.0 s** (audio is 337.1 s) ← also a problem
- **Search queries: avg 7.8 words, 0 bare queries** ← Sonnet did great here
- **Typography: 31 unique quotes, 5/9 spot-checked were verbatim from script**

The creative output was genuinely strong: pull-quote selections like
"أشرس الأعداء قد يكونون من داخل صفوفك" (placed right after the portrait
reveal — exactly where the hook belongs), structured chapter headings,
even a `date_stamp` card for "انقلاب ١٩٠٨" (the 1908 coup).  Sonnet
produced documentary-grade editorial work in one call.

But our validator was treating that work as broken.

## Three changes

### 1.  Raised the hard cap from 6 s to 8 s

The previous splitter aggressively chopped any shot above 6 s, producing
two identical consecutive halves.  74 % of your final plan was these
auto-split fragments — a visual stutter, not a feature.

Documentary pacing on portraits and pull quotes routinely runs 5–7 s.
Sonnet was instinctively planning this and we were chopping it.  The
new cap is 8 s; only true runaways get split.  When splitting is
needed, pieces target 5 s rather than 4 s.

Net effect on your test plan: ~67 shots, no auto-splits, ~5 s average.

### 2.  Plan duration constrained to audio duration

Your plan ran 391 s for a 337 s audio — 54 seconds of "planned video"
beyond where the audio ends.  Two fixes:

- **Prompt:** added explicit rule "the last shot must end at exactly
  the total audio duration provided — not later."
- **Validator:** now clips any shot extending past the audio end and
  drops any shot starting beyond it.  Logs both actions.

### 3.  Stricter verbatim rule for typography text

5/9 of your typography quotes were verbatim; the other 4 were
paraphrases or condensations.  This causes a subtle cognitive friction
when the (verbatim) caption underneath says something different from
the (paraphrased) hero text above it.

The prompt now says: "VERBATIM from the script — exact wording,
including diacritics … If a sentence is too long for typography, pick
a shorter contiguous sub-phrase from it.  No translation, no invention."

### 4.  Target shot duration recalibrated

Defaults from 4.5 s to 5.0 s, and the sizing function caps at 65 shots
(was 70).  Sonnet's natural instinct was ~5.8 s average — we're now
explicitly asking for what it would have chosen anyway.

| Duration | Old target | New target |
|---------:|-----------:|-----------:|
|     60 s |         13 |         12 |
|    180 s |         40 |         36 |
|    337 s |         70 |         64 |
|    480 s |         70 |         65 |

## New utility: audit_plan.py

A standalone auditor that reports plan quality.  Run it after every
plan generation:

```bash
python audit_plan.py output/al_askari_plan.json \
    --script samples/al_askari_script.txt \
    --audio output/al_askari_audio.mp3
```

It prints:

- Shot count, timeline, duration vs audio mismatch
- Gap / overlap detection
- Visual / motion / section histograms
- Auto-split fraction (with ✓/⚠/❌ marker)
- Typography quote provenance audit (verbatim / partial / paraphrased)
- Search query specificity check (bare 1-2-word queries are flagged)

This is the tool you use to evaluate each Sonnet generation
quantitatively — much faster than reading 106 JSON objects by eye.

## Files in this patch

- `plan.py` — replace; contains all three changes
- `audit_plan.py` — new utility; place next to phase3_run.py
- `test_smoke.py` — updated to match 8 s cap
- `PATCH_NOTES.md` — this file

`align.py`, `phase3_run.py`, and `test_resilient.py` from patch 1
remain unchanged.

## Re-running

```bash
python phase3_run.py \
    --script  samples/al_askari_script.txt \
    --audio   output/al_askari_audio.mp3 \
    --book-title "مذكرات جعفر العسكري" \
    --character-name "Jafar al-Askari" \
    --plan-only \
    --save-plan output/al_askari_plan_v2.json

python audit_plan.py output/al_askari_plan_v2.json \
    --script samples/al_askari_script.txt \
    --audio  output/al_askari_audio.mp3
```

What to expect:

- Auto-split count: ✓ (< 20 %, ideally 0)
- Plan timeline: ends within ±1 s of audio duration
- Verbatim quotes: ≥ 80 % of typography texts match script verbatim
- Visual distribution: typography 25–35 %, archive/portrait 20–30 %
  each, broll/location 10–20 %, section_mark/title_card 5–10 %
- ~60–65 shots, ~5 s average

If anything in the audit shows ⚠ or ❌, paste the audit output and the
problematic shots and we'll iterate.
