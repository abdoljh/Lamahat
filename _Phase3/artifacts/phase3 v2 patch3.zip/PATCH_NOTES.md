# Phase 3 v2 — Patch 3: Per-visual-type caps, field exclusivity, alignment warning

The v2 plan came back almost clean.  16 % auto-split was the only
remaining structural issue, and it traced to one specific cause:
shots in the 8.0–8.6 s range — right at the cap — getting chopped.

This patch makes three small, surgical changes that, applied to the
v2 Sonnet output (simulated), would produce **3 % auto-split** instead
of 16 % — basically eliminating the issue.

## What changed

### 1.  Per-visual-type duration caps

The old "8 s for everything" rule was too coarse.  Documentary holds
on different content types are inherently different lengths:

| Visual type   | Old cap | New cap | Why |
|---------------|--------:|--------:|-----|
| typography    |     8 s |    10 s | Reading time |
| portrait      |     8 s |    10 s | Contemplation time |
| archive       |     8 s |     8 s | Period photos rotate faster |
| broll         |     8 s |     8 s | Same |
| location      |     8 s |     8 s | Same |
| object        |     8 s |     8 s | Same |
| section_mark  |     8 s |     7 s | Interstitials stay snappy |
| title_card    |     8 s |     6 s | Open/close, not lingering |

Plus a 0.1 s floating-point tolerance — shots within 0.1 s of the cap
are kept intact rather than micro-split by snap-induced drift.

### 2.  Field exclusivity for title_card / section_mark / typography

In the v2 plan, title cards had both `typography_text` AND
`search_query` set — a logical inconsistency since they're rendered
from text on a designed background, not from an image search.

The prompt now states: "`title_card` and `section_mark` shots are
TYPOGRAPHY-ONLY: fill `typography_text` and leave `search_query`
empty."

A new `_normalise_fields()` post-processing step enforces this in
code too: typography-kind shots get `search_query=""`, image-kind
shots get `typography_text=""`.  The renderer can trust the contract.

### 3.  Prominent warning when interpolation is used

Your v2 log buried this:

```
WARNING phase3.align Backend whisperx failed: No module named 'whisperx'
WARNING phase3.align Backend whisper failed: No module named 'whisper'
INFO    phase3.align Aligned 653 words via interpolated backend
```

Reading that quickly, the last line looks like success.  In reality,
"interpolated" means character-rate estimates — not measured timings.
For the renderer this is going to matter: cuts will land on word
*positions* rather than word *boundaries* in the audio.

The new warning makes this loud:

```
WARNING phase3.align Using interpolated timings — character-rate
        estimates only.  For real word-level accuracy, install
        whisperx (pip install whisperx) or whisper (pip install
        openai-whisper).
```

## Simulated v3 output on your v2 Sonnet response

Re-running the v2 plan through the new post-processing (without a
fresh Sonnet call) produces:

- **60 shots** (was 64)
- **3 % auto-split** (was 16 %, 1 shot of 60)
- **Avg 6.52 s** (was 6.11 s)
- **Range 3.1–8.6 s** (was 3.1–7.9 s)
- One 8.6 s typography quote and one 8.5 s typography quote both
  preserved intact — perfect documentary pacing

## Files in this patch

- `plan.py` — per-type caps + tolerance + `_normalise_fields()` + prompt edits
- `align.py` — prominent interpolation warning
- `PATCH_NOTES.md` — this file

## Re-running

You can just regenerate to verify:

```bash
python phase3_run.py \
    --script  samples/al_askari_script.txt \
    --audio   output/al_askari_audio.mp3 \
    --book-title "مذكرات جعفر العسكري" \
    --character-name "Jafar al-Askari" \
    --plan-only \
    --save-plan output/al_askari_plan_v3.json

python audit_plan.py output/al_askari_plan_v3.json \
    --script samples/al_askari_script.txt \
    --audio  output/al_askari_audio.mp3
```

What I'd expect:

- Auto-split ≤ 5 %
- 100 % verbatim typography (the previous run already nailed this)
- ~60 shots, ~6.5 s average
- All other audit metrics ✓

If you'd like to skip re-running and proceed straight to renderer
work, that's also reasonable — the simulation confirmed the patch
behaves correctly on the existing Sonnet output.

## Worth considering before the next session

WhisperX installation is now the highest-impact remaining structural
improvement.  Without it, the plan is using character-count math to
guess when each word is spoken — which is fine for shot boundaries
within ~500 ms of the truth but means the captions won't line up
exactly with the voice.  With it, shot boundaries land on real word
boundaries in the audio waveform.

If Streamlit Cloud RAM constraints rule out WhisperX in production,
`pip install openai-whisper` is a viable middle ground: less precise
but real (50–300 ms accuracy vs WhisperX's <100 ms), and roughly half
the RAM footprint.

Either is a meaningful upgrade over interpolation, but neither blocks
moving forward.  The renderer can be developed against interpolated
timings and will benefit when better timings appear.
