# Issue 4 patch A v3.3 — title card + caption rendering

## What changed from v3.2

Adds `--book-cover-fit` for title cards.  The original v3.0–v3.2 only
supported "fill" (scale-and-crop), which works for 16:9 hero artwork
but crops the top and bottom off portrait-shaped covers (like a
photograph of a book on a table).

Three modes now available:

| Mode | Behaviour | Best for |
|---|---|---|
| `fill` (default) | Scale-and-crop to fill the frame | 16:9 hero artwork already prepared as a single image |
| `contain`        | Letterbox the whole image, cream side bars | Portrait covers where you want to preserve every pixel — header text, publisher logo, etc. |
| `blur_pad`       | Letterbox foreground, blurred-and-zoomed copy fills the bars | Portrait covers when the cover photo fills its own frame (not your case if it includes paper background) |

## Use

CLI (either tool):

```bash
python prebuild_assets.py \
    --plan output/al_askari_plan_v2.json \
    --script samples/al_askari_script.txt \
    --book-title "مذكرات جعفر العسكري" \
    --character-name "Jafar al-Askari" \
    --review-dir output/review/ \
    --character-portrait my_jafar.jpg \
    --book-cover my_book_cover.jpg \
    --book-cover-fit contain          # <- NEW

python render_plan.py \
    --plan output/al_askari_plan_v2.json \
    --audio output/al_askari_audio.mp3 \
    --review-dir output/review/ \
    --output output/final_cut.mp4
# fit mode auto-loaded from decisions.json

# Or override at render time:
python render_plan.py ... --book-cover-fit blur_pad ...
```

Precedence: CLI flag (`--book-cover-fit`) > dossier (`book.cover_fit`) > default `"fill"`.

The fit mode is persisted in `decisions.json` under `book.cover_fit`
when prebuild creates the dossier, so it survives the prebuild→render
handoff without needing the flag twice.

## Files modified in patch C

| File | Change |
|---|---|
| `phase3/typography.py` | New `cover_fit` field on `TypographySpec`; `_render_title_card_with_cover` dispatches on it; new helpers `_resize_cover_to_contain`, `_make_cover_contain`, `_make_cover_blur_pad` |
| `phase3/render.py` | New `RenderConfig.book_cover_fit` field; passes through to `_build_shot_asset` then `TypographySpec` |
| `prebuild_assets.py` | New `--book-cover-fit` flag; writes `book.cover_fit` into `decisions.json` |
| `render_plan.py` | New `--book-cover-fit` flag; reads from dossier when absent |
| `diagnose_issue4.py` | Checks for the new flags; prints `cover_fit` from the dossier |

## Verify after applying

```bash
python diagnose_issue4.py --review-dir output/review/
```

Expected new lines:

    ✓ --book-cover-fit flag found in CLI (patch C)   (in both render_plan and prebuild sections)
    cover_fit: contain                                (in the dossier section, if you used --book-cover-fit contain)

## What's still pending (issue 4 patch B)

Caption backplate: charcoal-bar + cream-text aesthetic.  Touches the
FFmpeg mux pipeline, shipped separately.
