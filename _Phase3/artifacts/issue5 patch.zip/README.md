# Issue 5 patch — user-marked file convention

## What this adds

A new resolution path for the review dossier: files in `review/shot_NN_<visual>/`
whose names match `my_*` or `user_*` (case-insensitive) with image
extensions `.jpg`, `.jpeg`, `.png`, `.webp` are picked up automatically
at render time. No `decisions.json` edit required.

This closes the practical gap that drove this change: replacing the bytes
behind a file like `shot_44_object/pexels_a.jpg` and expecting the
renderer to use it. That doesn't work today because `chosen_file` may be
empty (as it was for shot 44). Replacing or adding a new file with a
`my_*` or `user_*` prefix sidesteps the JSON contract entirely.

## Resolution order (NEW item 2)

1. `override` declared in `decisions.json`
2. **user-marked file in the shot folder** (NEW)
3. `pinned_portrait` (for `portrait` visuals only)
4. `chosen_file` from prebuild
5. fall through to live fetcher

The user-marked file beats the pin so per-shot edits override the global
character portrait — same precedence as `override`.

## Tiebreaker for multiple user files

Alphabetical. Stable across accidental deletions: removing `my_b.jpg`
from a folder also containing `my_a.jpg` still resolves to `my_a.jpg`.

## How to apply

Replace `phase3/sources/decisions.py` with the file in this bundle. No
other source changes are needed; the fetcher already calls
`Decisions.resolve()` in the right place.

## Verifying it worked

Run `verify_user_marked.py` from the `_Phase3/` directory:

```bash
python verify_user_marked.py
```

It runs 13 regex cases and 4 end-to-end resolution scenarios (matching
the patterns shot 5, 16, 28, 44 actually use). No network, no
Anthropic, no FFmpeg.

After that passes, in a real render run, look for these new INFO log
lines (they were previously DEBUG):

    Shot 5: user-marked file hit my_jafar.jpg
    Shot 16: pinned-portrait hit character.jpg
    Shot 28: chosen-file hit pexels_b.jpg

If a shot still falls through to the live fetcher, the log now tells
you why.

## Recommended workflow

1. Run prebuild as before to populate `output/review/`.
2. Open any `shot_NN_<visual>/` folder and look at the candidates.
3. To replace a shot's image:
   - drop a new file named `my_anything.jpg` (or `.png`, `.webp`) into
     that folder, OR
   - rename a candidate you like to start with `my_` or `user_`
4. Re-run `render_plan.py --review-dir output/review/`.

For portrait shots, the global character pin still works the same way
via `--character-portrait` at prebuild time.
