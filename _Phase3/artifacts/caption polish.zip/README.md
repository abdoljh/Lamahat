# Caption polish: backplate, font size, RTL punctuation

Three small fixes to the caption rendering pipeline.

## 1. Tighter backplate band (Fix 1)
`phase3/render.py`: `CAPTION_BACKPLATES` band changed from
`y=ih*0.85:h=ih*0.12` to `y=ih*0.88:h=ih*0.10`. Backplate now hugs the
caption text instead of dominating the bottom 12% of frame.

## 2. Larger caption font (Fix 2)
`phase3/subtitler.py`: `caption_sz = max(56, height // 11)`
(was `max(48, height // 14)`). At 1080p: 98px vs old 77px. Readable
at TV viewing distance.

## 3. RTL punctuation normalisation (Fix 3)
`phase3/subtitler.py:_esc()` now substitutes:
- `,` → `،` (U+060C Arabic comma)
- `;` → `؛` (U+061B Arabic semicolon)
- `?` → `؟` (U+061F Arabic question mark)

**Root cause**: Latin punctuation (U+002C, etc.) has *weak* bidi
directionality. libass relocates them to the leading (left) edge of
an Arabic line. Arabic punctuation has *strong* RTL directionality
and stays at the trailing edge. The bug in the screenshot
(`،` rendered to the left of the sentence) was actually a Latin `,`
in the source caption — the planner emits commas from English-source
generation.

Period (`.`) intentionally left as-is — acceptable at end of modern
Arabic typography; U+06D4 (Arabic full stop) is rare and renders
unevenly across Amiri.

## Apply
```bash
!unzip -o /content/caption_polish.zip -d /tmp/cp
!cp /tmp/cp/phase3/*.py /content/phase3/
!find /content/phase3 -name __pycache__ -exec rm -rf {} + 2>/dev/null
```

Note: no re-plan needed — `_esc()` runs at ASS write time.
