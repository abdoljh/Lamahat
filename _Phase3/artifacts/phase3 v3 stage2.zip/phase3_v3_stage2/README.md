# Phase 3 v3 — Stage 2: Image Fetching

This drop adds real image fetching from Library of Congress, Wikimedia
Commons, Internet Archive, and Pexels, with disk caching and Claude
vision scoring.  Plus three user-controlled overrides: explicit uploads,
filename-pattern uploads, and Phase 1a book-extract integration.

**Bottom line: after this drop, your `rough_cut.mp4` becomes
`final_cut.mp4` — image-kind shots get real photos instead of
placeholder cards.**

## What's in the zip

```
phase3/sources/
  __init__.py            ← Orchestrator (Fetcher, FetcherConfig)
  base.py                ← ImageCandidate, Source ABC, utilities
  cache.py               ← Disk cache keyed by query hash
  vision.py              ← Claude vision scorer (3-axis rubric)
  loc.py                 ← Library of Congress P&P
  wikimedia.py           ← Wikimedia Commons (refactored from your existing module)
  internet_archive.py    ← Internet Archive image search
  pexels.py              ← Pexels (refactored)
  user_upload.py         ← User-supplied images
  book_extract.py        ← Phase 1a-extracted photographs

render.py                ← Updated to consume the fetcher
render_plan.py           ← CLI with new Stage 2 flags
```

## Installation

Drop the `phase3/sources/` directory into your existing `phase3/`
package.  Replace `render.py` and `render_plan.py`.  No new pip
dependencies — uses `anthropic` and `Pillow` which are already in
your stack.

## The waterfall (asset resolution priority)

For each image-kind shot (portrait/archive/broll/location/object),
the fetcher tries these in order:

1. **User upload** — image at `--user-dir/shot_NN.jpg` (NN = 01-indexed
   shot number) or a `manifest.json` mapping.  Bypasses everything.
2. **Phase 1a book extract** — vision-scored against the shot's query,
   best match wins.  Requires `--anthropic-key` for matching.
3. **Cached web result** — instant if this query was fetched before.
4. **Live web search** — LoC → Wikimedia → Internet Archive → Pexels,
   vision-scored across all sources, top-ranked candidate kept.
5. **Placeholder card** — last resort if nothing returned a usable image.

The waterfall is also the *priority* order.  A user-supplied image
overrides everything; a book-extract match overrides web sources; etc.

## Three workflows

### Workflow A: just render with automatic fetching

```bash
python render_plan.py \
    --plan   output/al_askari_plan_v2.json \
    --audio  output/al_askari_audio.mp3 \
    --output output/final_cut.mp4 \
    --anthropic-key $ANTHROPIC_API_KEY \
    --pexels-key   $PEXELS_API_KEY \
    --book-title   "مذكرات جعفر العسكري" \
    --character-name "Jafar al-Askari"
```

The fetcher hits LoC + Wikimedia + IA + Pexels for each image shot,
vision-scores the candidates, picks the best, caches everything.
Subsequent renders of the same plan are instant (cache hits).

The `--book-title` and `--character-name` go into the vision rubric so
Claude knows what to score against.

### Workflow B: review what's needed, then supply images yourself

```bash
# 1. Generate the required-images manifest
python render_plan.py \
    --plan output/al_askari_plan_v2.json \
    --build-manifest output/required_images.txt

# 2. Review the manifest, drop images into a directory:
#    assets/user/shot_02.jpg   ← Jafar al-Askari portrait
#    assets/user/shot_04.jpg   ← Ottoman document
#    assets/user/shot_06.jpg   ← Constantinople photo
#    ...

# 3. Render — your images override everything else
python render_plan.py \
    --plan   output/al_askari_plan_v2.json \
    --audio  output/al_askari_audio.mp3 \
    --output output/final_cut.mp4 \
    --user-dir assets/user/ \
    --anthropic-key $ANTHROPIC_API_KEY
```

Files named `shot_NN.{jpg,png,webp,tif}` are auto-matched by shot
number.  Or use a `manifest.json` inside `--user-dir` for semantic
filenames:

```json
{
  "2":  "askari_portrait_1921.jpg",
  "4":  "ottoman_dissolution.png",
  "17": "shawkat_pasha.jpg"
}
```

### Workflow C: use Phase 1a book-extracted photos

Phase 1a already extracts photographs from your source PDF.  Point
the fetcher at them:

```bash
python render_plan.py \
    --plan         output/al_askari_plan_v2.json \
    --audio        output/al_askari_audio.mp3 \
    --output       output/final_cut.mp4 \
    --book-extracts output/phase1a/askari_photos.zip \
    --anthropic-key $ANTHROPIC_API_KEY \
    --book-title   "مذكرات جعفر العسكري" \
    --character-name "Jafar al-Askari"
```

The fetcher reads all photos from the ZIP, vision-scores each one
against each shot's query, and picks the best match per shot.  This is
usually the highest-quality source because the photos were curated by
the book's editor.

You can combine all three: `--user-dir` overrides take priority, then
book extracts, then web sources fill the gaps.

## Cache management

Default location: `~/.cache/lamahat/images/{query_hash}/`.

Each query directory contains:
- `meta.json` — query text, candidates with scores, the chosen best
- `cand_00.jpg`, `cand_01.jpg`, etc — all downloaded candidates

To force a re-fetch for a specific query, delete its directory.  To
wipe everything: `rm -rf ~/.cache/lamahat/images/`.

To disable caching: `--no-cache` (useful when iterating on queries).

To use a project-specific cache: `--cache-dir output/cache/`.

## Cost

Rough estimate per video at full quality:
- 30 image shots × 4 candidates × $0.005 per vision call = **~$0.60**
- Cached re-renders: $0.00

Set `--no-vision` to disable scoring entirely (uses source priority
order instead).  Saves cost; loses ranking quality.

## What I tested before shipping this

End-to-end on your al-Askari plan in a stripped environment:

1. **Stage 1 path still works** — rendered 3 shots with `fetcher=None`,
   confirmed identical placeholder behaviour as before.

2. **Stage 2 fallback when web sources fail** — rendered with the
   fetcher enabled but all web sources network-blocked.  Result: every
   image shot fell through to placeholder cards, video rendered
   normally with warnings logged.  No crashes.

3. **User upload by filename pattern** — placed `shot_02.jpg` in a
   user directory, rendered with `--user-dir`.  Verified the user
   image appeared in shot 2 with the planner's `slow_push` motion
   applied.

4. **User upload by manifest.json** — added `{"4": "askari.jpg"}` to
   manifest, verified shot 4 picked up the manifest-mapped file.

5. **Required-images manifest mode** — `--build-manifest` produces a
   readable listing of every image-kind shot with its visual type,
   duration, and search query.

What I couldn't test in the sandbox (you should verify on your end):

- **LoC / Wikimedia / IA / Pexels actual API responses** — the
  sandbox network blocked github.com and most data domains.  On your
  machine these should all work.
- **Vision scoring with real Claude API calls** — same reason.
- **Phase 1a integration** — I'd want to run it against a real
  photos.zip to make sure the ZIP extraction layout matches what
  Phase 1a actually writes.

## What to try first

```bash
# Smoke test: just generate the manifest
python render_plan.py \
    --plan output/al_askari_plan_v2.json \
    --build-manifest /tmp/manifest.txt
cat /tmp/manifest.txt
```

If that works, then:

```bash
# Single full render to validate the network paths
python render_plan.py \
    --plan   output/al_askari_plan_v2.json \
    --audio  output/al_askari_audio.mp3 \
    --output output/final_cut.mp4 \
    --anthropic-key $ANTHROPIC_API_KEY \
    --pexels-key   $PEXELS_API_KEY \
    --book-title   "مذكرات جعفر العسكري" \
    --character-name "Jafar al-Askari" \
    --verbose
```

`--verbose` prints which source returned each image and what the
vision scores were.  You can see the orchestrator's decisions in
real time.

## Known minor issues

- The motion expressions for `pan_right` / `pan_left` / `ken_burns`
  use `iw` (input width) in pixel-step calculations.  With the new
  buffer scaling at 1.6× output size, this works correctly, but the
  motion amplitude is somewhat conservative — half the buffer width.
  Tune up if you want more dramatic camera moves.

- Cache key is just `sha256(query)[:16]`.  Two queries that differ
  only in case or punctuation will be cached separately.  Easy to
  normalise later if it matters.

- The `motion_intensity` field on Shot is currently ignored by the
  renderer — all motions use the same intensity baked into the filter
  expressions.  Wire it through later if you want per-shot motion
  control.

## What comes next

Once you've watched the first real-image render and flagged anything
that needs adjustment, the remaining minor issues from earlier sessions
become the next session's agenda:

- Caption sizing fine-tune
- Section transition pacing
- The motion intensity wiring
- ElevenLabs TTS upgrade (separate, but the natural next quality leap)
