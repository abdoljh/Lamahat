# Issue 4 patch — captions + title-card redesign

Scope per Phase3.md §15.4, addressing the points from the latest
screenshots:

1. **Title card** is too quiet for an opening. Redesigned to support a
   full-frame book-cover background with an aged-gold title, no
   hairlines. The cream/hairline design is preserved as the fallback
   for when no cover is supplied.
2. **Subtitles** appear merged because consecutive captions touch each
   other with only a 0.1 s gap. Increased to 0.30 s with a 0.6 s
   minimum-visible floor for short shots.
3. **Caption font sizes** were already large enough in `render.py`
   (4.2 % of frame height), so no change to the body caption size.
4. **Title sub-line** bumped from 0.030 → 0.040 height-fraction; main
   title bumped from 0.085 → 0.110 for opening impact.

## Files modified

| File | Change |
|---|---|
| `phase3/typography.py` | New `GOLD_AGED` color, two new `TypographySpec` fields (`cover_image`, `accent_color`), split `_render_title_card` into a cover-mode and a cream-mode variant, bumped title size constants |
| `phase3/render.py` | `RenderConfig.book_cover`, pass through to `TypographySpec.cover_image`, new caption gap arithmetic in `_write_captions` |
| `prebuild_assets.py` | New `--book-cover PATH` flag; copies into `overrides/book_cover.<ext>` and records `book.cover_path` in `decisions.json` |
| `render_plan.py` | New `--book-cover PATH` flag; reads from dossier when absent |

## How to apply

Drop the four `.py` files in this bundle over their counterparts in
`_Phase3/`. The four `.diff` files show exactly what changed.

## How to use

The simplest path uses the dossier:

```bash
python prebuild_assets.py \
    --plan output/al_askari_plan_v2.json \
    --script samples/al_askari_script.txt \
    --book-title "مذكرات جعفر العسكري" \
    --character-name "Jafar al-Askari" \
    --anthropic-key "$ANTHROPIC_API_KEY" \
    --pexels-key "$PEXELS_API_KEY" \
    --review-dir output/review/ \
    --character-portrait my_jafar.jpg \
    --book-cover my_book_cover.jpg            # <- NEW

python render_plan.py \
    --plan output/al_askari_plan_v2.json \
    --audio output/al_askari_audio.mp3 \
    --review-dir output/review/ \
    --output output/final_cut.mp4
# Cover is picked up from decisions.json automatically.
```

Or override with the explicit flag (handy when reusing an existing
dossier with a different cover):

```bash
python render_plan.py \
    --plan output/al_askari_plan_v2.json \
    --audio output/al_askari_audio.mp3 \
    --review-dir output/review/ \
    --book-cover /alternative/cover.jpg \
    --output output/final_cut.mp4
```

## How to verify

After applying the patch, from `_Phase3/`:

```bash
python verify_title_card.py
```

It checks the new typography fields, renders both title-card variants
to a temp directory, and verifies the caption-gap arithmetic. Should
exit with `✓ All checks passed`.

## Image requirements

The book cover image should be at least **3072×1728** (the same 1.6×
buffer as portrait images). The renderer resizes-and-crops to fill
1920×1080 (CSS `background-size: cover` behaviour), so any aspect
ratio works — but very portrait-shaped covers may crop heavily at
top/bottom. Square or 4:3 cover photos work well.

The cover is rendered **static** (no Ken-Burns motion), so the only
sharpness floor is 1920×1080.

## What is NOT in this patch (deferred to issue 4 patch B)

The caption **backplate** (cream/charcoal bar behind subtitles).
Phase3.md §15.4c prescribes a semi-transparent FFmpeg `drawbox`
layered with the ASS subs. That touches the FFmpeg `_mux_final`
pipeline and the cream-text-on-charcoal-bar combination you picked.
Shipping it separately so this patch can be validated in isolation.

## Resolution order for the title card

1. `RenderConfig.book_cover` passed in explicitly by the caller
2. `book.cover_path` from `decisions.json` (when `--review-dir` is set)
3. None → renderer falls back to the cream/hairline design

So existing users who don't set a cover get the same opening as
before, just with a 30% larger title.
