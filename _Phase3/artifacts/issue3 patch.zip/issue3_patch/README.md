# Issue 3 patch — section transitions

**Scope**: tighten the planner's average shot duration target from
5.0–6.5 s down to 4.0–5.0 s, AND add a 0.3 s zoom-in motion accent on
`section_mark` shots to signal "new chapter".

This is the "Option 3" choice from the planning conversation: both moves
shipped together.

## What changed

### `phase3/plan.py`

| Hook | Before | After |
|---|---|---|
| `_SYSTEM_PROMPT` rule 3 — per-visual cap on `section_mark` | 2.5–7.0 s | 2.5–5.0 s |
| `_SYSTEM_PROMPT` rule 3 — pacing nudge | "favours longer holds (5–8 s)… don't rush them" | "TARGET RANGE: 4.0–5.0 s avg; most shots in 4–5 s; only resonant typography or portrait holds reach 6–8 s sparingly; cut faster around section_marks" |
| `_SYSTEM_PROMPT` rule 11 — section_mark window | 1.5–2.5 s (contradicted rule 3) | 2.5–5.0 s — brisk (consistent with rule 3) |
| `_USER_PROMPT_TMPL` framing | "favour slightly longer shots over too many short ones; MORE than target_shots is not [acceptable]" | "aim for the target rather than treating it as a ceiling; cut faster around section boundaries — the first 2–3 shots after each section_mark should be on the shorter end" |
| `build_shot_plan()` signature default | `target_shot_duration: float = 5.0` | `4.5` (docstring already said 4.5 — a pre-existing inconsistency, now resolved) |
| `_validate_plan()` `TARGET_PIECE` | `5.0` s | `4.5` s |

**Not touched** (per CLAUDE.md §6 — "don't lower the per-visual hard
caps"):

- `_validate_plan()` `HARD_CAPS` (typography/portrait 12 s; archive/
  broll/location/object 10 s; section_mark/title_card 7 s) — these are
  the safety-net upper limits on Sonnet output. The doc explicitly
  forbids lowering them.
- `_sized_target_shots()` cap of 65 shots — for the al-Askari run
  (391 s @ 4.5 s avg) this still resolves to 65, same as before.
- The per-visual `2.5–10 s`/`2.5–8 s` caps in rule 3 for typography/
  portrait and archive/broll/location/object. Those mirror the hard
  caps; touching them is the §6-forbidden direction.

### `phase3/render.py`

1. **New motion type `section_accent`** (`_section_accent()` in the
   `_MOTION_FILTERS` registry). Zoom expression:

   ```
   z = min(1.05, 1.00 + (0.05 / 8) * on)
   ```

   At 25 fps, `accent_frames = round(0.3 * 25) = 8`. The `min()` is
   self-clamping — once `on > 8` the zoom holds at 1.05 for the rest
   of the shot regardless of total duration. Centered crop, no pan.

2. **`RenderConfig.section_mark_accent: bool = True`** — opt-out flag.
   Set `False` to restore the pre-patch behaviour (all section_marks
   `static_hold`).

3. **Dispatch logic** (the only other behavioural change). Previously:

   ```python
   shot_motion = shot.motion if is_real_image else "static_hold"
   ```

   Now:

   ```python
   if is_real_image:
       shot_motion = shot.motion
   elif shot.visual == "section_mark" and config.section_mark_accent:
       shot_motion = "section_accent"
   else:
       shot_motion = "static_hold"
   ```

   Title_card, typography, chapter_heading shots remain `static_hold`
   — only section_marks animate.

**No upstream changes** to `prebuild_assets.py`, `render_plan.py`, or
the dossier schema. The accent is automatic on existing plans —
re-render the current `al_askari_plan_v2.json` and the four
section_mark shots (#9, #20, #30, #38) pick it up. The planner
tightening only takes effect on the *next* `--plan-only` run.

## Why this design

### Why these prompt hooks (and not lower hard caps)

The notebook log of the last run shows:

- Planner was already being called with `5.0s avg`, but Sonnet
  returned 48 shots at **avg 8.15 s** (range 3.9–12.2 s).
- Auto-split only fired 1/48 (2 %) — meaning Sonnet stayed *within*
  the hard caps. The hard caps aren't the problem; the prompt
  guidance is.
- Three places in the old prompt actively biased *upward*: rule 3
  ("favours longer holds"), the user-prompt asymmetric framing ("MORE
  than target_shots is not acceptable"), and the per-visual 10 s
  ceilings that gave Sonnet headroom to hug the top.

Lowering the hard caps would have caught the symptom, but CLAUDE.md
§6 explicitly forbids it (the caps were empirically tuned across three
iterations). The fix is to talk Sonnet *into* shorter shots, not to
trim runaways after the fact.

### Why a 0.3 s accent, not a longer animation

`section_mark` shots in the latest plan run 4.3–6.0 s long. A motion
that spans the whole shot (like `slow_push` at 1.00 → 1.08) would
keep typography moving while the viewer is trying to read the chapter
name — works for B-roll, fights typography.

A short 0.3 s lead-in lets the move register as "punctuation", then
the text holds long enough to read. This is the same logic
documentaries use for chapter cards (a brief slide-in or scale, then
a hold).

### Why opt-out flag, not opt-in

The accent is the intended new default. Issue 3 spec says to ship
both moves; we ship both as defaults. The flag exists so the next
review can A/B by re-rendering the *same* plan with
`section_mark_accent=False` if the accent reads wrong against the
real Arabic typography on the four actual section_marks.

## Files in this zip

```
issue3_patch/
├── README.md                 (this file)
├── phase3/
│   ├── plan.py               (patched, syntax-checked)
│   └── render.py             (patched, syntax-checked)
├── sandbox_test.py           (sandbox verification driver)
└── make_test_png.py          (test fixture generator)
```

## Sandbox verification (what was tested before shipping)

Ran in `/home/claude/issue3_patch/` with system `ffmpeg 6.1.1` and
Pillow:

```
$ python sandbox_test.py
loaded; motion keys: ['fast_push', 'ken_burns', 'pan_left',
  'pan_right', 'section_accent', 'slow_pull', 'slow_push']
rendered /tmp/sm_test_accent.mp4 (target 4.3s)
── ffprobe ──
codec_name=h264
width=1920
height=1080
r_frame_rate=25/1
nb_frames=108
duration=4.320000
bit_rate=380688

── frame samples ──
  t=0.00s  →  /tmp/sm_frame_0000.png  (50037 bytes)
  t=0.16s  →  /tmp/sm_frame_0160.png  (59636 bytes)
  t=0.32s  →  /tmp/sm_frame_0320.png  (63440 bytes)
  t=2.00s  →  /tmp/sm_frame_2000.png  (63612 bytes)

── regression: static_hold path still works ──
nb_frames=108
duration=4.320000
```

Frame-size growth (50 KB → 63 KB across the first 0.32 s, then
stable) is the zoom ramping in. PNG samples were inspected visually
— the "PART TWO" title grows ~5 % between t=0 and t=0.32, then holds.
The `static_hold` regression check confirms the existing path is
untouched (same 108 frames at 4.32 s).

## How to install in Colab

Same recipe as previous patches. After cell 0 (which clones the repo
into `/content/`), apply this patch *over* the cloned files:

```bash
cd /content
unzip -o /content/issue3_patch.zip
cp -f issue3_patch/phase3/plan.py   phase3/plan.py
cp -f issue3_patch/phase3/render.py phase3/render.py
# stale .pyc cache check — kernel restart is the surest fix
find phase3 -name __pycache__ -exec rm -rf {} +
```

## How to verify the patches are live

In Colab, before the long render:

```python
# Planner side
!grep -c "TARGET RANGE: aim for an" phase3/plan.py            # → 1
!grep -c "section_marks are punctuation, not pages" phase3/plan.py  # → 1
!grep "TARGET_PIECE = " phase3/plan.py                        # → 4.5
!grep "target_shot_duration: float = " phase3/plan.py         # → 4.5

# Renderer side
!grep -c "_section_accent" phase3/render.py                   # → 3 (def + registry + comment)
!grep -c "section_mark_accent" phase3/render.py               # → 4 (RenderConfig + 1 comment + dispatch + opt-out comment)
!grep "section_accent.*_section_accent" phase3/render.py      # → "section_accent": _section_accent,
```

## Expected results after re-running

### After re-planning (`!python phase3_run.py --plan-only ...`)

The new plan should show:

- **Average shot duration around 5.0–5.5 s** (not 8.15 s).
  This is *higher* than the 4.5 s prompt target — Sonnet always
  overshoots — but should land much closer to the target band than
  before. If avg comes in at 4.5–5.0 s, that's even better.
- **Shot count higher** — probably 55–65 shots (was 48). Total
  duration unchanged at 391 s.
- **Section_mark durations 2.5–5.0 s** (was 4.3–6.0 s, with one at
  5.8 s). Should look brisker.
- **Auto-split fraction stable or lower** (was 2 %). The new prompt
  walks Sonnet *toward* the target rather than capping it, so
  runaways should be rarer, not more frequent. If auto-split jumps
  above ~15 %, that's a signal the prompt is *too* aggressive and
  needs softening.

### After re-rendering (`!python render_plan.py ...`)

- All four section_mark shots now begin with a 0.3 s zoom-in (1.00 →
  1.05). The rest of each shot is a static hold at 1.05.
- Title_card, typography, chapter_heading shots unchanged (still
  static).
- Image shots unchanged.
- Render wall time unchanged (the zoompan filter on section_marks
  adds a few seconds of CPU at most across four 4–6 s clips).

### If the accent looks wrong

Re-render with:

```bash
# In whatever wrapper calls render_video(); pass a RenderConfig
# with section_mark_accent=False, or edit phase3/render.py:
#   section_mark_accent: bool = True  →  False
```

The flag exists precisely so a single render can be re-tried without
re-planning.

## Convergence notes (from CLAUDE.md)

This change converges with **Phase3.md §7.6** ("shot duration
distribution skews long — avg 9.09 s, target 5–6.5 s"). After this
patch, §7.6 should be closeable: the new target is 4.0–5.0 s and the
prompt actively pushes toward it.

It also strengthens the case for **Issue 4 patch B** (caption
charcoal-bar backplate). Faster rhythm makes white-on-outline
captions read less stable — if the post-patch render shows
caption stability problems, B becomes the next obvious tier-1.

## What's still open

Issue 3 closes after the next render lands and looks right. If it
does, the priority list from CLAUDE.md §5 moves to:

1. Issue 4 patch B (caption backplate) — small scope.
2. Phase3.md §15.1 / §15.2 (color grading knob, typography families
   B/C) — larger scope, no code yet.
3. Phase3.md §7 backlog (sources query strategy, vision fail-open,
   §8 strategic-path-C) — structural.

— Patch generated 2026-05-20.
