# Issue 4 patch A v3.4 — title card + caption rendering

## What changed from v3.3

Adds `--book-cover-align`.  When you use `contain` or `blur_pad` fit
modes, you can now position the cover left, right, or centred within
the frame.  The gold-title overlay automatically shifts to the
opposite side so it sits in the empty area, not on top of the cover.

Three alignments:

| `--book-cover-align` | Cover position | Title overlay sits |
|---|---|---|
| `center` (default) | centred, equal bars on both sides | centred over the cover |
| `left`             | flush left edge | in the right-side empty area |
| `right`            | flush right edge | in the left-side empty area |

For RTL composition (the natural Arabic reading order), `left` gives
you book-on-left + title-on-right.

## Use

```bash
# Prebuild — persists into decisions.json
python prebuild_assets.py ... \
    --book-cover my_book_trimmed.jpg \
    --book-cover-fit contain \
    --book-cover-align left

# Render — reads from dossier, or override at render time
python render_plan.py ... --review-dir output/review/
# or
python render_plan.py ... --book-cover-align right   # override only this run
```

Precedence: CLI flag > dossier `book.cover_align` > default `"center"`.

## Files in this bundle

| File | What changed in v3.4 |
|---|---|
| `phase3/typography.py` | New `TypographySpec.cover_align`; new `_h_offset_for_align` helper; `_make_cover_contain` and `_make_cover_blur_pad` honour alignment; title overlay shifts to the opposite side |
| `phase3/render.py` | New `RenderConfig.book_cover_align`; passes through to `_build_shot_asset` then `TypographySpec` |
| `prebuild_assets.py` | New `--book-cover-align` flag; writes `book.cover_align` into `decisions.json` |
| `render_plan.py` | New `--book-cover-align` flag; reads from dossier when absent |

Diagnose scripts unchanged from v3.3 — they don't need updating to
inspect cover_align because the dossier read at render time prints it
in the resolution log line.

## What's still pending (issue 4 patch B)

Caption backplate: charcoal-bar + cream-text aesthetic.  Touches the
FFmpeg mux pipeline, shipped separately.
