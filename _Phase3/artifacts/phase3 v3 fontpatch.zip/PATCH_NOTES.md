# Phase 3 v3 — Font Auto-Discovery Patch

Quick fix for the `"cannot open resource"` error when running
`render_plan.py`.

## What happened

`typography.py` had Amiri's TTF paths hardcoded to the Debian
location:

```
/usr/share/fonts/opentype/fonts-hosny-amiri/Amiri-Regular.ttf
```

That path only exists on Debian/Ubuntu systems with the
`fonts-hosny-amiri` package installed.  On Google Colab, macOS,
Fedora, Arch, or any custom Python env without that exact package,
Pillow throws `OSError: cannot open resource` when it tries to open
the font for the first render.

The earlier rough cut worked because I built it inside a sandbox
that happened to have `fonts-hosny-amiri` installed.

(WhisperX/Whisper install was a red herring — they're for alignment,
not rendering.  The error came from typography.py needing Amiri.)

## What this patch does

Replaces the hardcoded paths with auto-discovery that tries four
strategies in order:

1. **`LAMAHAT_AMIRI_DIR` environment variable** — if set, looks there
   first.  Useful when you have Amiri in a non-standard location.
2. **`fc-match`** — uses fontconfig to ask the OS where Amiri lives.
   Works on any Linux/macOS with `fontconfig` installed.
3. **Walks well-known install paths** — covers Debian, Fedora, Arch,
   macOS Homebrew, conda envs, and Colab.
4. **Downloads from upstream** as a last resort — fetches
   `Amiri-1.003.zip` from the official GitHub release into
   `~/.cache/lamahat/fonts/amiri-1.003/`.  One-time, then cached.

## How to install Amiri (skip the download path)

The download fallback works, but installing the font properly is
faster and cleaner.

**Debian/Ubuntu/Streamlit Cloud:**
```bash
sudo apt install fonts-hosny-amiri
```
(Your `packages.txt` for Streamlit Cloud already does this.)

**Google Colab:**
```bash
!apt-get install -y fonts-hosny-amiri
!fc-cache -fv
```
After this the auto-discovery will find it without needing the
download fallback.

**macOS:**
```bash
brew install --cask font-amiri
```
or with MacPorts:
```bash
port install fonts-amiri
```

**Fedora/RHEL:**
```bash
sudo dnf install amiri-fonts
```

**Arch:**
```bash
sudo pacman -S ttf-amiri
```

**Any other environment (including conda envs):**
```bash
# Either set the override:
export LAMAHAT_AMIRI_DIR=/path/to/dir/containing/Amiri-Regular.ttf

# Or let the renderer auto-download on first run.
# The download is ~3 MB and only happens once.
```

## Files in this patch

- `typography.py` — auto-discovery + new `_discover_amiri_fonts()` and
  `_download_amiri()` functions; `_font()` now falls back to
  `regular` if a weight is missing.
- `render.py` — placeholder card uses the `_font()` helper for
  consistency with the rest of the renderer.

## Verifying it works

After dropping the new files in, you can test discovery without
running the full pipeline:

```bash
python -c "from phase3.typography import FONT_PATHS; print(FONT_PATHS)"
```

You'll see one of:
- Paths in `/usr/share/fonts/...` (system install found)
- Paths in `~/.cache/lamahat/fonts/amiri-1.003/...` (auto-downloaded)
- An informative `RuntimeError` with install commands (nothing found,
  network unreachable)

Now retry the rendering command and it should run to completion.
