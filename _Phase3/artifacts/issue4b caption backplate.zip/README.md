# Issue 4 Patch B — caption charcoal-bar backplate

Closes CLAUDE.md §5 Tier-1 #2 / Phase3.md §7.8.

## What ships

`--caption-backplate {off,subtle,solid}` on `render_plan.py`, default
`subtle`. Injects a `drawbox` filter in `_mux_final` between grade and
ass, so the charcoal bar sits on the graded plate and the captions sit
on the bar.

| Mode    | Look                                                   |
| ------- | ------------------------------------------------------ |
| off     | No backplate; relies on ASS Outline=3 only             |
| subtle  | Charcoal #1A1A1A @ 55% opacity, bottom 12% of frame    |
| solid   | Same charcoal @ 80% opacity (for very bright source)   |

Geometry: `x=0:y=ih*0.85:w=iw:h=ih*0.12` — full width × 12% of frame
height. Sits directly behind the ASS Style `Arabic` band
(MarginV=40, Alignment=2 = bottom-centre).

## Filter chain order

`grade → backplate → ass`. Grade applies to the graded plate; backplate
sits on top of the graded plate; captions sit on top of the backplate.
Backplate is a no-op when no subtitle file is present.

## Performance

`drawbox` overhead is unmeasurable (sandbox bench: 81-100% of ungraded
baseline, well within noise). Effectively free.

## CLI

```bash
python render_plan.py \
    --plan        output/al_askari_plan_v2.json \
    --audio       output/al_askari_audio.mp3 \
    --review-dir  output/review/ \
    --book-cover-fit contain \
    --typography-family C \
    --grade       warm \
    --caption-backplate subtle \   # NEW
    --output      output/final_cut.mp4
```

Note: this zip also includes the with_cover overflow fix and the
curves-based warm/cool grade (from `with_cover_and_grade_speed.zip`).
You only need to apply *this* zip.

## Apply

```bash
!unzip -o /content/issue4b_caption_backplate.zip -d /tmp/issue4b
!cp /tmp/issue4b/phase3/*.py /content/phase3/
!cp /tmp/issue4b/render_plan.py /content/render_plan.py
!find /content/phase3 -name __pycache__ -exec rm -rf {} + 2>/dev/null; echo done

!python render_plan.py --help | grep -A2 caption-backplate
```
