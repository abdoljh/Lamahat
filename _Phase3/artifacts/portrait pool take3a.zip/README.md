# Portrait pool + book cover pool — TAKE 3

Same as take-2, plus: `<repo_root>/overrides/book_cover/` directory
pool with `--book-cover-pick N` selector.

## Layout

```
/content/
├── output/review/
├── overrides/
│   ├── character/        ← 5 portraits, round-robin
│   │   ├── 01_*.jpg
│   │   └── ...
│   └── book_cover/       ← 5 covers, --book-cover-pick N selects one
│       ├── cover_1.jpg
│       └── ...
├── phase3/
├── prebuild_assets.py
└── render_plan.py
```

## CLI

```bash
python render_plan.py ... --book-cover-pick 3   # picks 3rd cover sorted
```

Defaults to `--book-cover-pick 1`. Out-of-range values wrap (pick 6 of
5 = pick 1). Single-file `overrides/book_cover.jpg` still works
(legacy); file wins if both exist.

## Backward-compat

- `overrides/book_cover.jpg` single file → still works, takes priority
- `overrides/book_cover/` directory pool → new
- `overrides/character.jpg` single file → still works
- `overrides/character/` directory → portrait round-robin

## Apply

```bash
!unzip -o /content/portrait_pool_take3.zip -d /tmp/pp3
!cp /tmp/pp3/phase3/sources/decisions.py /content/phase3/sources/
!cp /tmp/pp3/render_plan.py /content/
!cp /tmp/pp3/prebuild_assets.py /content/
!find /content -name __pycache__ -exec rm -rf {} + 2>/dev/null
```

## Verify

After re-running prebuild, look for:
```
Portrait pool detected at /content/overrides/character — skipping pinned-portrait copy
Repo-root book cover directory pool detected at /content/overrides/book_cover — skipping prebuild copy
```

After re-running render:
```
Cover  : /content/overrides/book_cover/cover_3.jpg (pool pick #3 of 5 in overrides/book_cover/)
Shot 16: portrait pool hit p_0.jpg (rank 0 of 5)
Shot 27: portrait pool hit p_1.jpg (rank 1 of 5)
...
```
