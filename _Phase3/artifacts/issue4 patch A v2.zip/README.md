# Issue 4 patch A — title card + caption gap

## Files in this bundle

| File | Purpose |
|---|---|
| `phase3/typography.py` | Drop-in: new GOLD_AGED, TypographySpec fields, split title-card renderer, larger title sizes |
| `phase3/render.py` | Drop-in: RenderConfig.book_cover, caption GAP=0.15 / MIN_VISIBLE=0.6 |
| `prebuild_assets.py` | Drop-in: --book-cover flag |
| `render_plan.py` | Drop-in: --book-cover flag |
| `*.diff` | Unified diffs against the current repo, for review |
| `verify_title_card.py` | Self-test (run after applying) |
| `diagnose_issue4.py` | **If a render doesn't look patched, run this first** |

## How to apply

Drop the four `.py` files in this bundle over their counterparts in
`_Phase3/`. The four `.diff` files show exactly what changed.

After applying, run from `_Phase3/`:

```bash
python verify_title_card.py
```

Should print `✓ All checks passed`.

## How to use the cover

The book cover image should be at least **3072×1728** for best quality.
Plumbing two ways:

**Through the dossier** (preferred — also lets you set the pinned
character portrait at the same time):

```bash
python prebuild_assets.py \
    --plan output/al_askari_plan_v2.json \
    --script samples/al_askari_script.txt \
    --book-title "مذكرات جعفر العسكري" \
    --character-name "Jafar al-Askari" \
    --anthropic-key "$ANTHROPIC_API_KEY" \
    --pexels-key "$PEXELS_API_KEY" \
    --review-dir output/review/ \
    --character-portrait my_jafar.jpg \
    --book-cover my_book_cover.jpg            # <- NEW

python render_plan.py \
    --plan output/al_askari_plan_v2.json \
    --audio output/al_askari_audio.mp3 \
    --review-dir output/review/ \
    --output output/final_cut.mp4
# Cover picked up from decisions.json automatically.
```

**Explicit flag** (handy when reusing a dossier with a different cover,
or testing without re-running prebuild):

```bash
python render_plan.py \
    --plan output/al_askari_plan_v2.json \
    --audio output/al_askari_audio.mp3 \
    --review-dir output/review/ \
    --book-cover /path/to/cover.jpg \
    --output output/final_cut.mp4
```

## "I applied the patch but my video still looks the same"

Run the diagnostic from `_Phase3/`:

```bash
python diagnose_issue4.py --review-dir output/review/
```

It will tell you which file is unpatched, whether the dossier has a
cover entry, and *which title-card mode the renderer will use* on the
next render. The most common reason a render looks unchanged is that
no cover was supplied — neither via dossier nor via flag — so the
renderer fell back to cream mode (correctly, but with no visible book
background).

If diagnose reports CREAM MODE, either:
1. re-run `prebuild_assets.py` with `--book-cover PATH`, or
2. pass `--book-cover PATH` on the next `render_plan.py` invocation.

## What this patch does NOT change

- Caption text colour, font, and backplate: still white-on-charcoal-outline.
  Charcoal-bar + cream-text aesthetic is in patch B (separate).
- Section transitions, color grading, additional typography families:
  unchanged (out of issue-4 scope).

## Visible expected differences after applying

| Before | After |
|---|---|
| Title at 0.085 height-fraction (~92 px) | Title at 0.110 (~119 px) — 30% larger |
| Title subtitle at 0.030 (~32 px) | Subtitle at 0.040 (~43 px) — 33% larger |
| Title card always cream + hairlines | If cover supplied: cover photo + gold title, no hairlines |
| Consecutive captions touch with 0.10s gap | Captions have 0.30s gap, plus 0.6s min-visible floor |
