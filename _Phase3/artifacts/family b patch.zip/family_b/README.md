# §15.2 Typography Family B — Netflix-doc cinematic

Adds a second typography family (B, dark cinematic) alongside the
existing Family A (Aljazeera-editorial), selectable via
`--typography-family {A,B}`.  Family C lands in a follow-up.

## Files

```
family_b/
├── README.md
└── phase3/
    ├── typography_common.py   (NEW) shared tokens, helpers, FONT_PATHS, TypographySpec
    ├── typography_a.py        (NEW) Family A renderers (verbatim lift)
    ├── typography_b.py        (NEW) Family B renderers
    ├── typography.py          (REWRITTEN) dispatcher + public re-exports
    ├── render.py              (PATCHED) +RenderConfig.typography_family
    └── plan.py                (UNCHANGED from issue 3 patch — included for completeness)
```

## What changed

**Refactor**: the 1228-line `typography.py` split into three modules:

- `typography_common.py` — design tokens, font discovery, the
  `TypographySpec` dataclass, and all low-level helpers
  (`_font`, `_measure`, `_draw_text_rtl`, `_apply_grain`,
  `_make_canvas`, `_draw_hairline_rule`, `_draw_diamond`,
  `_wrap_by_width`, `_draw_centred_lines`, cover-fitting helpers)
  plus the new Family B palette and `_make_dark_gradient_canvas`.

- `typography_a.py` — the 5 Family A renderers, lifted verbatim from
  the old `typography.py`.  Only edits were import paths.  Behaviour
  is identical to before.

- `typography_b.py` — 5 new renderers for the cinematic dark family.

- `typography.py` — now a dispatcher.  Re-exports every public symbol
  `render.py` imports (`render`, `TypographySpec`, all palette
  constants, `FONT_PATHS`, `_font`, `_measure`, `_draw_text_rtl`,
  `_apply_grain`).  `render(spec, out_path)` reads `spec.family` and
  routes to the right registry.

**TypographySpec**: gained one new field — `family: Literal["A","B","C"] = "A"`.
Default keeps existing call sites working without modification.

**RenderConfig** (in `render.py`): gained `typography_family: str = "A"`.

**`_build_shot_asset`**: now accepts a `typography_family` kwarg and
threads it into the `TypographySpec` it constructs.

**Unknown family** → falls back to A with a warning.  Unknown template
within a family → falls back to that family's `pull_quote`.

## Family B design

Per Phase3.md §15.2: "Netflix-doc cinematic, dark gradient."  Concrete
choices:

- **Background**: vertical gradient `#201E1C` (top) → `#100F0E` (bottom),
  eased so the bottom darkens slightly faster (gamma 1.15).  Subtle
  grain on top — same `_apply_grain` helper as Family A, just over a
  dark base.
- **Primary text**: `#ECE6DC` warm off-white in Amiri Bold (vs Family
  A's `#26231F` charcoal in mixed weights).  Off-white needs more
  weight than charcoal does on cream to feel anchored, so even
  section_mark and date_stamp get Bold.
- **Secondary text** (subtitles, attribution): `#AAA296` dim off-white
  in Amiri Regular (Family A used italic; on dark, italic at small
  sizes reads thin and slightly anaemic).
- **Accent**: `#BC9440` deep gold for all rules + the `date_stamp`
  date itself.  Slightly more saturated than Family A's `GOLD_AGED`
  because rules need to *register* on a dark gradient.
- **Rules**: shorter than Family A (10–14% of width vs 18–22%) and
  slightly thicker (×1.5 thickness multiplier).  Solid, not the
  semi-transparent overlay Family A uses — opacity 1.0 because a
  semi-transparent rule disappears on the gradient.
- **No diamond ornament** on section_marks. The gold rule alone is
  the punctuation.  Cleaner, less editorial — more documentary.
- **No decorative «»** quote marks on pull_quotes. The bold off-white
  type and gradient carry the weight.
- **Title card (no cover)**: pure dark gradient, off-white title, gold
  rule, dim subtitle.  No cream-mode fallback in Family B.
- **Title card (with cover)**: same photo composite as Family A, but
  the bottom-weighted darkening gradient reaches α=225 instead of
  α=190 (off-white title needs more darkness underneath than gold
  does), and any letterbox bars in `contain`/`blur_pad` modes use
  `DARK_CARD` instead of `CREAM_LIGHT`.

## How to install in Colab

```bash
cd /content
unzip -o /content/family_b_patch.zip
cp -f family_b/phase3/typography_common.py phase3/typography_common.py
cp -f family_b/phase3/typography_a.py      phase3/typography_a.py
cp -f family_b/phase3/typography_b.py      phase3/typography_b.py
cp -f family_b/phase3/typography.py        phase3/typography.py
cp -f family_b/phase3/render.py            phase3/render.py
find phase3 -name __pycache__ -exec rm -rf {} +
```

Then **restart the runtime** (the refactor changed `typography.py`'s
import graph; stale modules will confuse things).

## How to verify

```python
# All five new/changed files import cleanly
import phase3.typography_common
import phase3.typography_a
import phase3.typography_b
import phase3.typography
print(phase3.typography.render)                    # callable
print(phase3.typography_common.TypographySpec)     # dataclass

# Family registry is wired
print(list(phase3.typography._FAMILY_REGISTRIES))  # ['A', 'B']

# Backward-compat: render.py's exact import line still works
from phase3.typography import (
    CHARCOAL, CREAM_DEEP, CREAM_LIGHT, CREAM_MEDIUM, FONT_PATHS, GRAPHITE,
    TypographySpec, WARM_GREY,
    _apply_grain, _draw_text_rtl, _font, _measure,
    render as render_typography,
)
print("backward-compat OK")
```

Then a smoke render:

```python
from pathlib import Path
from phase3.typography_common import TypographySpec
from phase3.typography import render

for fam in ("A", "B"):
    for tpl in ("title_card", "section_mark", "pull_quote", "name_reveal", "date_stamp"):
        spec = TypographySpec(
            template=tpl, family=fam,
            text="مذكرات جعفر العسكري",
            subtitle="1885 – 1936",
            width=1920, height=1080,
        )
        render(spec, Path(f"/tmp/typo_{fam}_{tpl}.png"))
```

Open the 10 PNGs — Family B should be dark with gold accents.

## CLI wiring

Add the flag to whatever script you use as the entry point (the doc
calls it `phase3_run.py`; I don't have it locally, so here's the snippet):

```python
# In your argparse setup:
parser.add_argument(
    "--typography-family",
    choices=["A", "B"],          # add "C" when shipped
    default="A",
    help="Typography family: A=Aljazeera editorial (cream), "
         "B=Netflix-doc cinematic (dark)",
)

# Where you build RenderConfig:
config = RenderConfig(
    # …existing fields…
    typography_family=args.typography_family,
)
```

If you share the entry script I can patch it directly in a follow-up;
this snippet is one drop-in line + one keyword arg.

## Sandbox verification (done before shipping)

Smoke test rendered all 5 templates × 2 families (10 PNGs) at 1920×1080.
All files saved cleanly, sizes 494–696 KB (cream cards are slightly
larger because of grain-noise compression cost; dark cards compress
better).  Contact-sheet inspection confirmed:

- Family A renders identically to the pre-refactor version (the
  verbatim lift preserves behaviour).
- Family B's gradient grades correctly top-to-bottom.
- Gold rules register clearly against the dark background.
- Off-white text reads cleanly against the gradient at all sizes
  (title_main, section_main, pull_quote_lg/md/sm, name_main, date_huge).
- `date_stamp`'s gold date dominates the frame as designed — the only
  template where gold is the primary text colour.

The smoke test used DejaVu-Serif as a stand-in for Amiri (the sandbox
has no Arabic font and can't reach github.com to download Amiri).
Glyphs render as tofu boxes but **layout, palette, gradient, rules,
sizing, and hierarchy are all verifiable from the contact sheet**.
In your Colab environment with bundled Amiri fonts, Arabic glyphs
will render correctly through the same code paths.

## What's open

- **Family C** (manuscript, sepia + ornament) — Phase3.md §15.2 part 2.
- **Closing title_card clipping** — the bug found in the issue-3
  render where the credit line "تحقيق وتقديم: نجدة فتحي صفوت…"
  overflows the cream bar.  Not addressed here; flagged for a separate
  patch.
- **Issue 4B** (caption charcoal backplate) — small scope.

## Convergence

The refactor cleans up the path for Family C: drop in
`typography_c.py` with a `RENDERERS` dict and register it in
`typography.py`'s `_FAMILY_REGISTRIES`.  No further changes to
`typography_common.py`, `render.py`, or `plan.py` required.

— Patch generated 2026-05-21.
