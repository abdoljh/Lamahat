# §15.2 Typography Family C — manuscript, sepia + ornament

Adds Family C alongside the existing A (cream/editorial) and B
(dark/cinematic).  Selectable via `--typography-family {A,B,C}`.

## Files

```
family_bc/
├── README.md
├── render_plan.py                    (PATCHED — accepts C in choices)
└── phase3/
    ├── typography_common.py          (unchanged from B patch)
    ├── typography_a.py               (unchanged from B patch)
    ├── typography_b.py               (unchanged from B patch)
    ├── typography_c.py               (NEW)
    ├── typography.py                 (PATCHED — registers C)
    ├── render.py                     (unchanged from B patch)
    └── plan.py                       (unchanged from B patch)
```

If you already installed the Family B patch, you only need to copy
`typography_c.py`, the updated `typography.py`, and the updated
`render_plan.py`.

## Family C design

- **Palette**: aged paper `#E8DCC0` → `#D9C8A0` (vignette), sepia ink
  `#3D2F1F`, faded burgundy `#7A2E2A` for accents.
- **Background**: aged-paper canvas with radial vignette darkening at
  corners (gentle near centre, ramps with gamma 1.8) + double-applied
  grain for heavier paper texture.
- **Ornament**:
  - **Manuscript brackets** flank section_mark, name_reveal, and
    title_card.  Drawn as geometric L-shapes with inward terminus
    dots — no external assets, all polygons.
  - **Double-rules** instead of single hairlines.  Two parallel
    burgundy lines with a small gap — classic Quranic-margin look.
  - **Visible «» quote marks** at burgundy_dim on pull_quotes
    (Family A draws them α=0.08, Family B drops them entirely).
- **Text weights**: same Amiri Bold/Italic as A.  No Quran weight
  dependency — keeps the font discovery surface identical.

## Install (Colab)

```bash
cd /content
unzip -o /content/family_c_patch.zip
cp -f family_bc/phase3/typography_c.py phase3/typography_c.py
cp -f family_bc/phase3/typography.py   phase3/typography.py
cp -f family_bc/render_plan.py         render_plan.py
find phase3 -name __pycache__ -exec rm -rf {} +
```

Restart the runtime.

## Run

```bash
!python render_plan.py \
  --plan         output/al_askari_plan_v2.json \
  --audio        output/al_askari_audio.mp3 \
  --review-dir   output/review/ \
  --book-cover-fit contain \
  --output       output/final_cut_C.mp4 \
  --no-captions \
  --typography-family C \
  > output/render_C.log 2>&1 &
```

## Verification

```python
import phase3.typography
print(list(phase3.typography._FAMILY_REGISTRIES))   # ['A', 'B', 'C']
```

Then render any single card:

```python
from pathlib import Path
from phase3.typography_common import TypographySpec
from phase3.typography import render

spec = TypographySpec(template="section_mark", family="C",
                      text="الفصل الثاني", subtitle="الضابط الشاب",
                      width=1920, height=1080)
render(spec, Path("/tmp/test_C.png"))
```

## Sandbox verification (done)

All 5 templates rendered at 1920×1080 with stand-in fonts.  Sheet
inspection confirmed:
- Vignette grades from PAPER_LIGHT centre to PAPER_EDGE corners
- Burgundy brackets render with inward terminus dots flanking each
  primary title
- Double-rules display correctly with a visible gap
- Pull-quote `«»` marks anchor the left/right margins prominently
- Date_stamp's huge sepia number dominates the frame

Family A and B unaffected (separate registries; same TypographySpec).

— Patch generated 2026-05-21.
