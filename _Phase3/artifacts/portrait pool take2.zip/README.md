# Portrait pool — TAKE 2 (auto-discover from repo root + prebuild defers)

## What went wrong in the b3d notebook

The portrait_pool patch was correct, but two problems prevented it from working:

1. **The patch wasn't applied** — the b3d notebook didn't include the
   `cp /tmp/pp/...` step. `decisions.py` ran the unpatched code.
2. **Even applied, `prebuild_assets.py` would sabotage the pool** —
   it accepts `--character-portrait` and copies the file into
   `<review_dir>/overrides/character.png`, then sets
   `pinned_portrait: "overrides/character.png"` in `decisions.json`.
   The renderer's fallback chain (pool → pinned file → chosen_file)
   would still try the pool first, but the b3d log shows only Shot 16
   resolved, and it hit `character.jpg` (the prebuild-copied file).

## What this patch does

### 1. `phase3/sources/decisions.py` (unchanged from previous patch)
Auto-discovers `<repo_root>/overrides/character/` by walking up from
`review_dir`. Sorted round-robin by portrait-shot rank, modulo-wrapped.

### 2. `render_plan.py` (unchanged from previous patch)
Auto-discovers `<repo_root>/overrides/book_cover.{jpg,jpeg,png,webp}`
when `--book-cover` not passed and `book.cover_path` doesn't resolve.

### 3. `prebuild_assets.py` (NEW)
**Defers to the repo-root overrides when they exist.** When
`<repo_root>/overrides/character/` has at least one image, prebuild:
- skips the pin-portrait copy
- ignores `--character-portrait` (logs that it's ignored)
- leaves `pinned_portrait` unset in `decisions.json`

Same logic for `<repo_root>/overrides/book_cover.*` — skip the prebuild
copy, leave `book.cover_path` unset, let render_plan auto-discover.

This means: **once you drop files into `/content/overrides/character/`
and `/content/overrides/book_cover.jpg`, running the notebook
end-to-end no longer clobbers them.** No `decisions.json` editing,
no `--character-portrait` flag tweaks.

## Apply

```bash
!unzip -o /content/portrait_pool_take2.zip -d /tmp/pp2
!cp /tmp/pp2/phase3/sources/decisions.py /content/phase3/sources/
!cp /tmp/pp2/render_plan.py /content/
!cp /tmp/pp2/prebuild_assets.py /content/
!find /content -name __pycache__ -exec rm -rf {} + 2>/dev/null
```

## Verify before re-running

```bash
!ls /content/overrides/character/
!ls /content/overrides/ | grep book_cover
```

Then run the notebook. Look for these log lines in prebuild:
```
Portrait pool detected at /content/overrides/character — skipping pinned-portrait copy
Repo-root book cover detected at /content/overrides/book_cover.jpg — skipping prebuild copy
```

And in render's per-shot logs:
```
Shot N: portrait pool hit <filename> (rank K of 5)
```

For your 5 portraits across multiple portrait shots, you should see rank
values cycling 0,1,2,3,4,0,1,... — one per portrait shot.

## Layout assumed

```
/content/
├── output/
│   └── review/        ← decisions.json
├── overrides/
│   ├── character/
│   │   ├── 01_*.jpg
│   │   ├── 02_*.jpg
│   │   └── ...
│   └── book_cover.jpg
├── phase3/
├── prebuild_assets.py
└── render_plan.py
```
