# Family C v3 — colored Quran glyphs now active

Single fix over v2: enable Pillow's `embedded_color=True` on Family C
headline draws so the COLR/CPAL palette baked into
`AmiriQuranColored.ttf` actually renders.  The red i-dots (نقاط
الإعجام) above and below letters now appear, matching what the
font produces in the standalone Pillow snippet.

## What was wrong in v2

Pillow only activates a font's coloured-glyph layers when
`draw.text(..., embedded_color=True)` is set.  My `_draw_text_rtl`
helper didn't pass that flag, so even with the colored font selected,
Pillow rendered only the monochrome outline — visually identical to
the plain Amiri Quran B&W variant.

Without diacritics in the input string, the colored layer only
includes the i-dots that distinguish Arabic letters (ب vs ت, ج vs خ,
etc.).  Those dots are baked into the font as separate coloured
glyph layers — they're what your standalone snippet renders in red.
With diacritics in the input, the tashkeel marks also pick up the
palette colour.

## Code change

**`typography_common.py`** — added two things:
1. `_font_has_color_palette(font)` — checks whether a loaded font
   exposes a COLR table (with a path-name heuristic fallback for
   exotic Pillow builds).
2. `_draw_text_rtl(..., embedded_color=False)` and
   `_draw_centred_lines(..., embedded_color=False)` — opt-in kwarg
   that, when True *and* the font has a colour palette, routes the
   draw through Pillow's `embedded_color=True` path.  When the font
   is monochrome, the flag is a no-op.

Families A and B are unaffected — they don't pass the flag.

**`typography_c.py`** — added `embedded_color=True` to the four
headline draw calls (title_card_with_cover, title_card_paper,
section_mark, name_reveal).  Body text (pull_quote), subtitles, and
date_stamp digits are left alone — they use Amiri Bold, which has no
colour palette to activate anyway.

## Install

```bash
cd /content
unzip -o family_c_v3_patch.zip
cp -f family_c_v3_dist/phase3/typography_common.py phase3/typography_common.py
cp -f family_c_v3_dist/phase3/typography_c.py      phase3/typography_c.py
find phase3 -name __pycache__ -exec rm -rf {} +
```

Restart runtime.

## Verification

After restart:

```python
from phase3.typography_common import _font_has_color_palette, _font
print(_font_has_color_palette(_font("quran_colored", 80)))   # True
print(_font_has_color_palette(_font("bold", 80)))            # False
```

Then re-render a Family C smoke card and check the i-dots are red.

## Sandbox verification

Re-rendered all 5 Family C templates.  Title_card, section_mark, and
name_reveal now show red i-dots on letters that carry them; pull_quote
body (Bold) and date_stamp digits (Bold) remain in solid sepia.

— Patch generated 2026-05-21.
