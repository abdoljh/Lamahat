# Typography dispatcher fix — re-export `SIZES`

## What broke

After the issue-2 refactor, `SIZES` (the typography size dict) moved
from the old `typography.py` monolith into `typography_common.py`.
The dispatcher's re-export list missed it, so:

- `verify_title_card.py` → `AttributeError: module 'phase3.typography' has no attribute 'SIZES'`
- `diagnose_issue4.py`   → same error

Both scripts predate the refactor and read `t.SIZES["title_main"]`
directly off the dispatcher.

## What this fix does

Adds `SIZES` to the `from .typography_common import (...)` line and
to `__all__` in `phase3/typography.py`. **Two lines added, zero
behaviour change.** This honours the CLAUDE.md §6 rule
("Don't move the public typography exports out of `typography.py`")
— the verify/diagnose scripts get their pre-refactor contract back
without needing to be patched themselves.

## Audit of other missing re-exports

I scanned all five verify/diagnose scripts for dispatcher attribute
reads (`t.<UPPER_CASE>`). Only `SIZES` was missing. `GOLD_AGED`,
`FONT_PATHS`, `TypographySpec`, `render` were all already exported.

## Apply

```bash
!unzip -o /content/typography_sizes_fix.zip -d /tmp/sizes_fix
!cp /tmp/sizes_fix/phase3/typography.py /content/phase3/typography.py
!find /content/phase3 -name __pycache__ -exec rm -rf {} + 2>/dev/null; echo done
```

## Verify

```bash
!python verify_title_card.py --book-cover my_book.jpg   # passes the SIZES assertions
!python diagnose_issue4.py --review-dir output/review/  # passes title_main / title_sub checks
```
