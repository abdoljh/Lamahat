# Phase 3 v2 — Patch 1: Robust planner

This patch fixes the JSON parse error you hit on the al-Askari script.
Drop these three files in place; no other changes needed.

## What broke

The planner asked Sonnet for **96 shots** (337 s / 3.5 s avg). Each shot
object is ~250 output tokens. 96 × 250 = 24,000 output tokens, but
`max_tokens` was set to 8,000. Sonnet ran out of room and the response
got truncated mid-object — leaving a trailing comma that `json.loads`
choked on at character 24,129 (line 736).

## Four changes in this patch

1.  **Smarter target shot count.** `_sized_target_shots()` scales
    sub-linearly above 3 minutes and caps at 70. Your 337 s script now
    asks for 70 shots instead of 96 — documentary pacing, not TikTok.

2.  **Streaming + bigger budget.** `max_tokens` raised from 8,000 to
    24,000. The call now uses `client.messages.stream()` so very long
    responses don't time out and we get partial output even if the
    model hits an early stop. `stop_reason` is logged when not
    `end_turn` so you'll see "I should have lowered target_shots" in
    the warning if it ever runs short again.

3.  **Resilient JSON parser.** When the response is truncated mid-shot,
    `_extract_json_resilient()` walks the `shots` array object by
    object, returning everything complete before the malformed
    chunk. So even if Sonnet cuts off at shot 65 of 70, you get 64
    valid shots, not zero.

4.  **Raw response saved on every call.** Pass `debug_dir=…` (or use
    `--save-plan`, which sets it automatically) and the raw Sonnet
    response goes to `output/planner_raw_response.txt` next to the
    plan. On parse failure it writes `_FAILED.txt` instead and the
    error message includes the path. No more guessing what Sonnet
    actually said.

## Prompt tweaks

Two small clarifications to the system prompt:

- Minimum shot duration raised from 1.5 s → 2.5 s (documentary feel).
- Hard instruction added: "returning fewer than {target} shots is OK,
  returning more is not." This guards against future inflation.

## Verifying the patch works

```bash
python test_resilient.py
```

Tests four scenarios: clean response, truncated mid-object, truncated
mid-string, and the target-sizing math. All four pass.

## Now try again

Same command as before:

```bash
python phase3_run.py \
    --script samples/al_askari_script.txt \
    --audio output/al_askari_audio.mp3 \
    --book-title "مذكرات جعفر العسكري" \
    --character-name "Jafar al-Askari" \
    --plan-only \
    --save-plan output/al_askari_plan.json
```

You should see:
- `target=70 shots, 4.5s avg, 337.1s total` in the log
- A `output/planner_raw_response.txt` file alongside `al_askari_plan.json`
- The shot-by-shot summary printed cleanly

If anything still fails, `output/planner_raw_response_FAILED.txt` will
contain exactly what Sonnet returned — paste it to me and we'll debug
from concrete evidence.

## About your alignment

Look at your output:

```
Audio  : output/al_askari_audio.mp3
...
INFO  phase3.align  No audio file — using interpolation fallback
```

The header prints the audio path, then immediately says "No audio file."
That means `Path("output/al_askari_audio.mp3").exists()` returned False
when `align()` was called.  Most likely cause: the path is relative to
*your* shell's working directory but not Python's at the moment of the
check.

This patch fixes the misleading log message — you'll now see one of:

- `No audio path provided — using interpolation fallback` (None passed)
- `Audio file not found at <path> (cwd=<cwd>) — ...` (the real cwd issue)

To use a real alignment backend, you'll need:

```bash
pip install openai-whisper        # smaller, lighter (Whisper-only)
# OR
pip install whisperx              # full forced alignment (~1.7 GB)
```

And pass an absolute path or one resolvable from your invocation cwd:

```bash
python phase3_run.py \
    --script "$(pwd)/samples/al_askari_script.txt" \
    --audio  "$(pwd)/output/al_askari_audio.mp3" \
    --align-only --align-backend whisper
```

Even Whisper-only gives 50–300 ms timing accuracy — plenty for cuts.
