# TAKE 4 — explicit `resources/` directory, no walk-up

## What was wrong in take-3

`Decisions._portrait_pool_root()` walked up from `review_dir` looking
for any `overrides/` sibling. But prebuild **creates** an
`overrides/` directory inside review (where it copies the pinned
portrait), and that captured the walk-up search — the resolver found
`/content/output/review/overrides/` first and never reached
`/content/overrides/`. So `_list_portrait_pool()` returned [], the
resolver fell through to the legacy file path, and you got the same
single image on every portrait shot.

Same bug bit the book cover discovery in render_plan.py — silently
fell through and dropped you back at "book.cover_path not in dossier".

## The fix

1. **Rename** `overrides/` → `resources/`. No historical conflict.
2. **No walk-up.** Resolve a single explicit path from
   `$LAMAHAT_RESOURCES` env var, defaulting to `/content/resources`
   on Colab.
3. Behavior is unambiguous: if `$LAMAHAT_RESOURCES/character/` has
   images, pool. If not, no pool. Nothing in between.

## Layout

```
/content/
├── output/
│   └── review/        ← prebuild writes decisions.json here
├── resources/         ← user drops images here
│   ├── character/
│   │   ├── jafar_at_window.jpg
│   │   ├── jafar_in_office.jpg
│   │   ├── jafar_in_uniform.png
│   │   ├── jafar_order_of_the_medjidie.jpg
│   │   └── jafar_profile.jpg
│   └── book_cover/
│       ├── memoirs_cover.jpg
│       └── ...
├── phase3/
├── prebuild_assets.py
└── render_plan.py
```

## Migration cell (run ONCE before everything else)

```python
import shutil
from pathlib import Path

# Move overrides/ → resources/ if it exists
old = Path("/content/overrides")
new = Path("/content/resources")
if old.exists() and not new.exists():
    shutil.move(str(old), str(new))
    print(f"✓ renamed {old} → {new}")
elif old.exists():
    # Both exist — merge old into new
    for child in old.iterdir():
        dst = new / child.name
        if not dst.exists():
            shutil.move(str(child), str(dst))
            print(f"  moved {child.name}")
    old.rmdir() if not any(old.iterdir()) else None
    print(f"✓ merged {old} into {new}")

# Remove any stale `overrides/` that prebuild created under review
for stale in [Path("/content/output/review/overrides"),
              Path("/content/overrides")]:
    if stale.is_dir():
        shutil.rmtree(stale)
        print(f"✓ removed stale {stale}")

# Verify
chars  = sorted((new/"character").glob("*"))   if (new/"character").is_dir()  else []
covers = sorted((new/"book_cover").glob("*"))  if (new/"book_cover").is_dir() else []
print(f"\nresources/character/  : {len(chars)} files")
for f in chars: print(f"   - {f.name}")
print(f"resources/book_cover/ : {len(covers)} files")
for f in covers: print(f"   - {f.name}")
assert chars and covers, "Move portraits/covers into /content/resources/ first"
```

## Apply

```python
import subprocess
from pathlib import Path

ZIP = Path("/content/portrait_pool_take4.zip")
assert ZIP.exists()
subprocess.run(["unzip", "-oq", str(ZIP), "-d", "/tmp/pp4"], check=True)
for rel in ["phase3/sources/decisions.py", "render_plan.py", "prebuild_assets.py"]:
    subprocess.run(["cp", f"/tmp/pp4/{rel}", f"/content/{rel}"], check=True)
for pyc in Path("/content").rglob("__pycache__"):
    subprocess.run(["rm", "-rf", str(pyc)])

# Behavior-level checks (not just substring matches)
import importlib.util
spec = importlib.util.spec_from_file_location("d", "/content/phase3/sources/decisions.py")
mod  = importlib.util.module_from_spec(spec)
import sys, types
sys.modules.setdefault("phase3", types.ModuleType("phase3"))
sys.modules.setdefault("phase3.sources", types.ModuleType("phase3.sources"))
spec.loader.exec_module(mod)
assert mod.Decisions._resources_root().name == "resources", "patch didn't take"
print("✅ Patch verified — pool will resolve from /content/resources/")
```

## Sandbox-proven

Test fixture replicates your exact failure mode:
- `/tmp/repo_t4/output/review/overrides/character.jpg` (stale legacy file)
- `/tmp/repo_t4/resources/character/jafar_{1..5}.jpg`

Result (6 portrait shots):
```
Pool (5): jafar_1.jpg … jafar_5.jpg
shot 16 → jafar_1.jpg
shot 27 → jafar_2.jpg
shot 44 → jafar_3.jpg
shot 61 → jafar_4.jpg
shot 72 → jafar_5.jpg
shot 85 → jafar_1.jpg  ← wraps
```

The stale `overrides/character.jpg` did NOT capture discovery.
