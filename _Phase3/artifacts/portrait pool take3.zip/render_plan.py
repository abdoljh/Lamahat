#!/usr/bin/env python3
"""
render_plan.py — Render a saved shot plan JSON to MP4.

Stage 2 driver: real image fetching from LoC/Wikimedia/Internet
Archive/Pexels, with optional user uploads and Phase 1a book extracts.
Image-shot fallback to placeholder cards when fetching fails.

Usage
-----
    python render_plan.py --plan PATH [options]

Required
--------
    --plan PATH         Shot plan JSON (from phase3_run.py --plan-only)

Audio
-----
    --audio PATH        Phase 2 TTS MP3.  Optional.

Output
------
    --output PATH       Output MP4  [default: output/rough_cut.mp4]
    --width N           [default: 1920]
    --height N          [default: 1080]
    --fps N             [default: 25]
    --no-captions       Skip caption burn-in

Image fetching (Stage 2)
------------------------
    --anthropic-key KEY     Enables vision scoring     (or ANTHROPIC_API_KEY)
    --pexels-key KEY        Enables Pexels source      (or PEXELS_API_KEY)
    --user-dir PATH         User-supplied images (overrides automatic)
    --book-extracts PATH    Phase 1a photos directory or ZIP
    --book-title TEXT       Used in vision-scoring rubric
    --character-name TEXT   Used in vision-scoring rubric
    --cache-dir PATH        Image cache  [default: ~/.cache/lamahat/images]
    --no-cache              Disable disk caching
    --no-vision             Disable Claude vision scoring

Typography
----------
    --typography-family {A,B}
                        Pick the typography family used for all card
                        renders (title_card, section_mark, pull_quote,
                        name_reveal, date_stamp).
                          A = Aljazeera-editorial, cream/charcoal (default)
                          B = Netflix-doc cinematic, dark gradient
                        Family C (manuscript) reserved for a follow-up.

Modes
-----
    --build-manifest PATH   Write required-images manifest and exit

Logging
-------
    --verbose               Show DEBUG-level logs
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
import time
from pathlib import Path

_HERE = Path(__file__).resolve().parent
if str(_HERE.parent) not in sys.path:
    sys.path.insert(0, str(_HERE.parent))

from phase3.plan import load_plan
from phase3.render import RenderConfig, render_video
from phase3.sources import Fetcher, FetcherConfig


def _load_dotenv(path: Path) -> None:
    """Tiny .env loader — no external dependency."""
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, _, v = line.partition("=")
        k = k.strip()
        v = v.strip().strip('"').strip("'")
        if k and k not in os.environ:
            os.environ[k] = v


_LAST_PCT = {"v": -1}


def _make_progress(verbose: bool):
    def _on_progress(label: str, frac: float) -> None:
        pct = int(frac * 100)
        if pct != _LAST_PCT["v"] or verbose:
            _LAST_PCT["v"] = pct
            bar_len = 30
            filled = int(bar_len * frac)
            bar = "█" * filled + "░" * (bar_len - filled)
            print(f"\r  [{bar}] {pct:3d}%  {label:<70}",
                  end="", flush=True)
        if frac >= 1.0:
            print()
    return _on_progress


def main() -> int:
    ap = argparse.ArgumentParser(
        prog="render_plan.py",
        description="Render a saved shot plan to MP4 with optional image fetching.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ap.add_argument("--plan", required=True, metavar="PATH")
    ap.add_argument("--audio", metavar="PATH")
    ap.add_argument("--output", default="output/rough_cut.mp4", metavar="PATH")
    ap.add_argument("--width",  type=int, default=1920)
    ap.add_argument("--height", type=int, default=1080)
    ap.add_argument("--fps",    type=int, default=25)
    ap.add_argument("--no-captions", action="store_true",
                    help="Skip burning subtitles into the video.  Use when "
                         "the audio narration is sufficient on its own and "
                         "you don't want the on-screen text.")

    ap.add_argument("--anthropic-key", default="", metavar="KEY")
    ap.add_argument("--pexels-key", default="", metavar="KEY")
    ap.add_argument("--user-dir", metavar="PATH")
    ap.add_argument("--book-extracts", metavar="PATH")
    ap.add_argument("--book-title", default="", metavar="TEXT")
    ap.add_argument("--character-name", default="", metavar="TEXT")
    ap.add_argument("--cache-dir", metavar="PATH")
    ap.add_argument("--no-cache", action="store_true")
    ap.add_argument("--no-vision", action="store_true")
    ap.add_argument("--review-dir", metavar="PATH",
                    help="Consume a pre-render review dossier from this "
                         "directory (output of prebuild_assets.py).  When "
                         "set, each shot's image resolves via the dossier's "
                         "override/pin/chosen before any source query.")
    ap.add_argument("--book-cover", metavar="PATH",
                    help="Path to a book-cover image.  Title-card shots "
                         "render with this image as full-frame background "
                         "and a gold title overlay.  When --review-dir is "
                         "also set, this flag overrides whatever cover "
                         "path is recorded in the dossier.")
    ap.add_argument("--book-cover-fit",
                    choices=("fill", "contain", "blur_pad"),
                    default=None,
                    help="How the cover image is fitted into the 16:9 "
                         "frame.  Overrides whatever was recorded in the "
                         "dossier.  If neither is set, defaults to 'fill'. "
                         "'fill' = scale-and-crop, 'contain' = letterbox "
                         "with cream bars, 'blur_pad' = letterbox with a "
                         "blurred-cover background.")
    ap.add_argument("--book-cover-align",
                    choices=("center", "left", "right"),
                    default=None,
                    help="Horizontal alignment of the cover when the fit "
                         "mode leaves spare space.  Overrides the dossier. "
                         "Defaults to 'center'.  Only meaningful with "
                         "contain or blur_pad.  The gold title overlay "
                         "shifts to the opposite side automatically.")
    ap.add_argument("--book-cover-pick",
                    type=int, default=1, metavar="N",
                    help="When the auto-discovered book-cover override is "
                         "a DIRECTORY (`<repo>/overrides/book_cover/`) "
                         "rather than a file, select the Nth cover (1-indexed, "
                         "sorted by filename, case-insensitive).  Default 1. "
                         "Out-of-range values wrap via modulo, so --book-cover-pick 6 "
                         "with 5 covers picks #1.  Ignored when --book-cover "
                         "is passed explicitly or when overrides/book_cover.<ext> "
                         "is a single file.")

    ap.add_argument("--typography-family",
                    choices=("A", "B", "C"),
                    default="A",
                    help="Typography family for all card renders. "
                         "A = Aljazeera-editorial cream/charcoal (default), "
                         "B = Netflix-doc cinematic dark gradient, "
                         "C = Manuscript sepia + ornament.")

    ap.add_argument("--build-manifest", metavar="PATH",
                    help="Write required-images manifest and exit")
    ap.add_argument("--verbose", action="store_true")

    args = ap.parse_args()

    level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(levelname)s  %(name)s  %(message)s",
        stream=sys.stdout,
    )
    logging.getLogger("phase3").setLevel(level)

    _load_dotenv(Path(".env"))
    _load_dotenv(_HERE / ".env")

    anthropic_key = args.anthropic_key or os.environ.get("ANTHROPIC_API_KEY", "")
    pexels_key    = args.pexels_key    or os.environ.get("PEXELS_API_KEY", "")

    plan_path = Path(args.plan)
    if not plan_path.exists():
        print(f"ERROR: plan file not found: {plan_path}", file=sys.stderr)
        return 1
    shots = load_plan(plan_path)
    print(f"\nPlan   : {plan_path}  ({len(shots)} shots)")

    cache_dir = (
        None if args.no_cache
        else (Path(args.cache_dir) if args.cache_dir else None)
    )
    fc = FetcherConfig(
        anthropic_api_key=anthropic_key,
        pexels_api_key=pexels_key,
        cache_dir=cache_dir,
        user_dir=Path(args.user_dir) if args.user_dir else None,
        book_extracts=Path(args.book_extracts) if args.book_extracts else None,
        book_title=args.book_title,
        character_name=args.character_name,
        enable_vision=not args.no_vision,
        review_dir=Path(args.review_dir) if args.review_dir else None,
    )

    # --build-manifest mode: write the manifest and exit
    if args.build_manifest:
        manifest_path = Path(args.build_manifest)
        fetcher = Fetcher(fc)
        fetcher.build_manifest(shots, manifest_path)
        print(f"Manifest written → {manifest_path}")
        return 0

    audio_path = None
    if args.audio:
        audio_path = Path(args.audio)
        if not audio_path.exists():
            print(f"ERROR: audio file not found: {audio_path}", file=sys.stderr)
            return 1
        print(f"Audio  : {audio_path}")

    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    print(f"Output : {out_path}")
    print(f"Config : {args.width}×{args.height} @ {args.fps} fps  "
          f"captions={'off' if args.no_captions else 'on'}")
    print(f"Vision : {'on' if fc.vision_enabled else 'off'}  "
          f"Cache: {'off' if args.no_cache else 'on'}  "
          f"User dir: {args.user_dir or '–'}  "
          f"Book extracts: {args.book_extracts or '–'}")
    _family_labels = {
        "A": "Aljazeera-editorial cream",
        "B": "Netflix-doc cinematic dark",
        "C": "Manuscript sepia + ornament",
    }
    print(f"Family : {args.typography_family} "
          f"({_family_labels[args.typography_family]})")
    if args.review_dir:
        print(f"Review : {args.review_dir} (dossier consulted before fetcher)")
    print()

    fetcher = Fetcher(fc)

    # Resolve the book cover.  Precedence: explicit --book-cover flag
    # over the dossier's book.cover_path, with a final fallback to an
    # auto-discovered `overrides/book_cover.{jpg,jpeg,png,webp}` file
    # (case-insensitive).  When none resolve, title cards keep the
    # original cream design.
    #
    # The auto-discovery step matters because running the notebook
    # end-to-end re-creates decisions.json without book.cover_path; the
    # user shouldn't have to re-edit it after every regeneration.
    book_cover_path: Path | None = None
    if args.book_cover:
        book_cover_path = Path(args.book_cover).expanduser().resolve()
        if not book_cover_path.exists():
            print(f"ERROR: --book-cover path not found: {book_cover_path}",
                  file=sys.stderr)
            return 1
        print(f"Cover  : {book_cover_path} (from --book-cover)")
    elif args.review_dir and fetcher.decisions is not None:
        rel = (fetcher.decisions.book or {}).get("cover_path")
        if rel:
            candidate = (Path(args.review_dir) / rel).resolve()
            if candidate.exists():
                book_cover_path = candidate
                print(f"Cover  : {candidate} (from dossier book.cover_path)")
            else:
                print(f"WARN   : dossier book.cover_path={rel} but file is "
                      f"missing — trying overrides/ auto-discovery",
                      file=sys.stderr)

    # Auto-discovery fallback: looks for either
    #   `<repo_root>/overrides/book_cover.<ext>`  (single file, legacy)
    #   `<repo_root>/overrides/book_cover/`        (directory pool, new)
    # File wins if both exist (avoid surprising users mid-migration).
    # When the directory pool wins, --book-cover-pick N selects the Nth
    # entry (1-indexed, modulo-wrapped).
    BOOK_EXTS = (".jpg", ".jpeg", ".png", ".webp")
    if book_cover_path is None and args.review_dir:
        review_path = Path(args.review_dir).resolve()
        # Walk up looking for an overrides/ sibling
        overrides_dir: Path | None = None
        for candidate in [review_path, *review_path.parents[:3]]:
            d = candidate / "overrides"
            if d.is_dir():
                overrides_dir = d
                break

        if overrides_dir is not None:
            # 1. Look for single-file override (legacy).
            for candidate in sorted(overrides_dir.iterdir(),
                                    key=lambda x: x.name.lower()):
                if (candidate.is_file()
                        and candidate.stem.lower() == "book_cover"
                        and candidate.suffix.lower() in BOOK_EXTS):
                    book_cover_path = candidate
                    print(f"Cover  : {candidate} "
                          f"(auto-discovered from overrides/)")
                    break

            # 2. No single file — look for directory pool.
            if book_cover_path is None:
                pool_dir = overrides_dir / "book_cover"
                if pool_dir.is_dir():
                    pool = sorted(
                        [f for f in pool_dir.iterdir()
                         if f.is_file()
                         and f.suffix.lower() in BOOK_EXTS],
                        key=lambda x: x.name.lower(),
                    )
                    if pool:
                        # 1-indexed pick, modulo-wrapped.
                        pick = max(1, args.book_cover_pick)
                        idx = (pick - 1) % len(pool)
                        book_cover_path = pool[idx]
                        print(f"Cover  : {book_cover_path} "
                              f"(pool pick #{pick} of {len(pool)} "
                              f"in overrides/book_cover/)")

    # Resolve the cover fit mode.  Precedence: CLI flag > dossier > "fill".
    cover_fit = "fill"
    if args.book_cover_fit is not None:
        cover_fit = args.book_cover_fit
        if book_cover_path:
            print(f"Cover fit: {cover_fit} (from --book-cover-fit)")
    elif args.review_dir and fetcher.decisions is not None:
        dossier_fit = (fetcher.decisions.book or {}).get("cover_fit")
        if dossier_fit in ("fill", "contain", "blur_pad"):
            cover_fit = dossier_fit
            if book_cover_path:
                print(f"Cover fit: {cover_fit} (from dossier book.cover_fit)")

    # Resolve cover alignment.  Precedence: CLI flag > dossier > "center".
    cover_align = "center"
    if args.book_cover_align is not None:
        cover_align = args.book_cover_align
        if book_cover_path:
            print(f"Cover align: {cover_align} (from --book-cover-align)")
    elif args.review_dir and fetcher.decisions is not None:
        dossier_align = (fetcher.decisions.book or {}).get("cover_align")
        if dossier_align in ("center", "left", "right"):
            cover_align = dossier_align
            if book_cover_path:
                print(f"Cover align: {cover_align} (from dossier book.cover_align)")

    cfg = RenderConfig(
        width=args.width,
        height=args.height,
        fps=args.fps,
        add_captions=not args.no_captions,
        fetcher=fetcher,
        book_cover=book_cover_path,
        book_cover_fit=cover_fit,
        book_cover_align=cover_align,
        typography_family=args.typography_family,
    )

    t0 = time.perf_counter()
    try:
        render_video(
            shots, out_path,
            audio_path=audio_path,
            config=cfg,
            on_progress=_make_progress(args.verbose),
        )
    except Exception as exc:
        print(f"\nERROR: {exc}", file=sys.stderr)
        if args.verbose:
            import traceback
            traceback.print_exc()
        return 1

    elapsed = time.perf_counter() - t0
    size_mb = out_path.stat().st_size / (1024 * 1024)
    print(f"\nDone in {elapsed:.0f}s  —  {out_path}  ({size_mb:.1f} MB)")
    return 0


if __name__ == "__main__":
    sys.exit(main())