# Family C v2 — manuscript with calligraphic headlines + geometry fixes

Three fixes over the v1 patch you tested:

1. **Headlines now use Amiri Quran Colored** (or Amiri Quran B&W
   fallback, or Amiri Bold if neither is installed).  Applies to
   title_card main, section_mark main, name_reveal main.  Body text
   stays in Amiri Bold (pull_quote lines, all subtitles).  Date stamp
   stays in Bold (digits don't benefit from calligraphy).
2. **Brackets are now correctly sized** L-shapes (`[` and `]` corner
   marks).  Earlier renders showed full rectangles because the
   brackets were sized to 1.05–1.1× text height, so their top/bottom
   arms collided with the rules above/below.  Now sized at 0.80–0.85×
   the *ink* height (not the padded calligraphy height) with the
   "terminus dots" removed — they read as noise at 1080p.
3. **Pull_quote «» quote marks** now sit just outside the text block
   edges (0.5× quote-size gap), not at the page margins.  Sized to
   1.0× body text instead of 1.6× so they punctuate rather than
   dominate.

## Font discovery additions

`typography_common.py` `_FONT_ALIASES` now recognises:
- `"quran"`: `AmiriQuran.ttf` or `Amiri Quran.ttf` (with space)
- `"quran_colored"`: `AmiriQuranColored.ttf`

These slots are **optional** — discovery only requires `regular` +
`bold`.  When Quran fonts aren't present, Family C falls back to
Amiri Bold for headlines (same as v1 behaviour).

## What's in this zip

```
family_c_v2/
├── README.md
├── render_plan.py                      (unchanged from earlier C patch)
└── phase3/
    ├── typography_common.py            (PATCHED — adds quran slots)
    ├── typography_c.py                 (PATCHED — bracket/quote fixes + Quran wiring)
    ├── typography.py                   (unchanged from earlier C patch)
    ├── typography_a.py                 (unchanged)
    ├── typography_b.py                 (unchanged)
    ├── plan.py                         (unchanged)
    └── render.py                       (unchanged)
```

If you already installed the earlier C patch, only `typography_common.py`
and `typography_c.py` are different.

## Install

```bash
cd /content
unzip -o family_c_v2_patch.zip
cp -f family_c_v2/phase3/typography_common.py phase3/typography_common.py
cp -f family_c_v2/phase3/typography_c.py      phase3/typography_c.py
find phase3 -name __pycache__ -exec rm -rf {} +
```

Restart runtime.  Confirm the Quran fonts are in the discovery path
(`_Phase3/fonts/` or whatever directory `_discover_amiri_fonts` finds
first).  The provided fonts.zip ships them.

## Verification

```python
from phase3.typography_common import FONT_PATHS
print(FONT_PATHS.get("quran_colored"))    # should be a path, not None
print(FONT_PATHS.get("quran"))            # should also be a path
```

If both are `None`, Family C will silently fall back to Bold (still
works, just no calligraphic feel).

## Sandbox verification

All 5 templates rendered cleanly with the real fonts + Quran weights.
- title_card: calligraphic headline, dates clear of headline, brackets
  framing properly without rectangle effect
- section_mark: calligraphic headline, bracket+text+double-rule stack
  reads as a manuscript margin marker
- pull_quote: «» sit just outside the text block at body weight
- name_reveal: calligraphic name + brackets + double-rule + dates
- date_stamp: Amiri Bold digits at huge size (unchanged from v1)

## What's still open

- The closing title_card clipping bug (long credit line overflows the
  cream bar) is independent of family choice and not addressed here.

— Patch generated 2026-05-21.
