# Hotfix: UnboundLocalError in render_plan.py + notebook cleanup

## The bug that broke take-4

In `render_plan.py`, I added `import os` inside `main()` at line 319.
Python's lexical scoping rules turned every `os` reference *anywhere*
in `main()` into a local-name lookup — including the existing one at
line 221 (`os.environ.get("ANTHROPIC_API_KEY")`).  That line runs
before line 319, so `os` is "referenced before assignment" →
`UnboundLocalError` → renderer crashes immediately, never produces
output → user's `final_cut_A.mp4` is the pre-patch file from an
earlier run.

Prebuild was working correctly all along (look at cell 17 output:
`Portrait pool detected at /content/resources/character`).  The pool
detection landed.  The render side did not.

## The fix

Hoist `import os` to module scope in render_plan.py, prebuild_assets.py,
and decisions.py.  Drop the inline imports.  Three-line diff total.

## Files in this zip

| File | Change |
|------|--------|
| `render_plan.py` | Remove inline `import os` at line 319 |
| `prebuild_assets.py` | Hoist `import os` to module scope; remove inline |
| `phase3/sources/decisions.py` | Hoist `import os` to module scope; remove inline |

## Apply

```python
import subprocess
from pathlib import Path
subprocess.run(["unzip","-oq","/content/take4_hotfix.zip","-d","/tmp/hot4"], check=True)
for rel in ["render_plan.py", "prebuild_assets.py", "phase3/sources/decisions.py"]:
    subprocess.run(["cp", f"/tmp/hot4/{rel}", f"/content/{rel}"], check=True)
for pyc in Path("/content").rglob("__pycache__"):
    subprocess.run(["rm","-rf",str(pyc)])
print("✓ Hotfix applied")
```

## Verify

```bash
!python render_plan.py --help | head -3
# Should print "usage: render_plan.py ..." — NOT crash
```

If this works, your cell 22 render command will work too.
