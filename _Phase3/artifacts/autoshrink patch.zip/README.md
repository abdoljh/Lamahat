# Auto-shrink headlines — title_card / section_mark / name_reveal

Closes CLAUDE.md §5 Tier-1 #3 (closing title_card clipping bug) plus the
"final card text appears incomplete" observation. Both stem from the
same root cause: headline renderers used a fixed `_size(spec, ...)` font
with no width check, so any text wider than the frame just overflowed.

## What changed

**One helper** in `typography_common.py`:

```python
_fit_text_to_width(draw, text, weight, start_size_px, max_width,
                   min_size_px=None, _font_loader=None)
    → (font, size_px)
```

Linear decrement from `start_size_px` until the rendered text measures
≤ `max_width`. Defaults: floor at `max(12, start_size_px // 2)` — never
shrinks below 50% of the planned size. Optional `_font_loader` for
families that use a custom font factory (Family C's `_headline_font`).

Why linear and not binary search: ~50-step worst case (200→12 px),
runs once per card, keeps the chosen size as close as possible to the
plan — only shrinks as far as it absolutely must.

**Nine call sites patched** (3 per family, headlines only):

| Family | title_card                  | section_mark      | name_reveal       |
| ------ | --------------------------- | ----------------- | ----------------- |
| A      | `_render_title_card_cream`  | `_render_section_mark` | `_render_name_reveal` |
| B      | `_render_title_card_dark`   | `_render_section_mark` | `_render_name_reveal` |
| C      | `_render_title_card_paper`  | `_render_section_mark` | `_render_name_reveal` |

Width budget = `spec.width * (1 - 2 * MARGINS["horizontal_pct"])` =
80% of frame width (1536 px at 1920 wide). Same column width
`pull_quote` already uses.

Subtitles and pull_quotes untouched per your scope choice.

## Sandbox proof

Rendered the documented offender from CLAUDE.md against Family A and C:

| Text                                       | Width @ 118px | Result after fit  |
| ------------------------------------------ | ------------- | ----------------- |
| `مذكرات جعفر العسكري` (short)              | 900px ≤ 1536  | no change, 118px  |
| `تحقيق وتقديم: نجدة فتحي صفوت ومحمود زايد` (long) | 1731px > 1536 | shrunk to 104px, 1525px ✓ |

See `previews/preview_*.png` for visuals.

## Compatibility

- Behaviour unchanged for any headline that already fit (≥99% of shots
  in the current plan, based on character-length distribution).
- Family C's `_headline_metrics()` and `HEADLINE_VPAD_FRAC` are still
  honoured — the shrink happens before metrics, so padding still
  computes off the actual rendered font.
- Family C's bracket sizing (sized to ink height `mh`, not padded
  height `mh_padded`) still works — `mh` is measured after the shrink.
- No planner changes. No CLI changes. No re-plan needed.
- CLAUDE.md §6 "things not to touch": HARD_CAPS untouched, planner
  untouched, `embedded_color=True` calls untouched, `HEADLINE_VPAD_FRAC`
  untouched, dispatcher exports unchanged.

## Apply

```bash
!unzip -o /content/autoshrink_patch.zip -d /tmp/autoshrink
!cp /tmp/autoshrink/phase3/*.py /content/phase3/
!find /content/phase3 -name __pycache__ -exec rm -rf {} + 2>/dev/null; echo done
```

## Verify

```bash
!python verify_title_card.py --book-cover my_book.jpg
!python diagnose_issue4.py --review-dir output/review/
```

Then a real render — the closing title_card and the final-shot
typography text should both now stay within frame regardless of length.

## What this does NOT fix

The "captions appear incomplete" observation may have a second source
beyond the typography card: the burned ASS subtitles on the closing
shot. If after this patch you still see clipped *.ass* captions on the
final shot, the next step is `render.py:_write_captions` —
`MIN_VISIBLE = 0.6` may be cutting off the last caption when the shot
ends before the caption's intended out-point. Flag it after the render
and I'll tackle it.
