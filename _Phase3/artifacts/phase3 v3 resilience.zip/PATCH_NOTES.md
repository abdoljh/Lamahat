# Phase 3 v3 — Resilience & Plan-Merge Patch

Two issues addressed.

## Issue 1: 72% auto-split rate

The auditor caught the bigger structural problem: Sonnet originally
planned 43 shots; the validator split them into 69 (50 of those 69
were duplicate pieces of an original).

The split logic was too aggressive — 8-second hard caps on
archive/broll/location/object meant any shot Sonnet held for even 8.2
seconds got cut in half.  And the splitter never merged anything back,
so legitimate 13-second pull quotes became three identical 4.3-second
shots, breaking the documentary hold and chopping captions into pieces.

### What changed

In `plan.py`'s `_validate_plan()`:

**Caps raised** to match documentary practice:

| Visual type    | Old cap | New cap |
|---------------|---------|---------|
| typography    | 10s     | 12s     |
| portrait      | 10s     | 12s     |
| archive       |  8s     | 10s     |
| broll         |  8s     | 10s     |
| location      |  8s     | 10s     |
| object        |  8s     | 10s     |
| section_mark  |  7s     |  7s     |
| title_card    |  6s     |  7s     |

**Merge pass added** at the end of validation: adjacent shots with
identical `visual` + `search_query` + `typography_text` fuse back
together.  This catches anything still slipping through the cap, AND
fixes plans where Sonnet itself emitted duplicates.

Caption windows merge correctly — when two adjacent shots have
different caption text, both texts join into one continuous caption.

### Impact

Re-validating your existing 64-shot plan: 64 → 59 shots (5 merged).
Worst case from your 69-shot plan: estimated 69 → ~43 shots, matching
Sonnet's original count.  Three-piece typography splits (the worst
form) disappear entirely.

## Issue 2: Render crashed mid-pipeline

The Stage 2 fetch logic was missing per-shot exception handling.  One
bad image (corrupt download, unusual format, vision API hiccup) could
kill the entire render.

### What changed

**`sources/__init__.py`** — `_fetch_live()` now wraps:
- Each download in its own try/except (one failed URL doesn't drop the rest)
- Each vision-scoring call in its own try/except (one API error doesn't drop the rest, neutral score applied)

**`render.py`** — the per-shot loop now wraps:
- `_build_shot_asset()` and `_png_to_clip()` together in a try/except
- On failure: emit an `_error_card()` showing the shot index and
  error message, then continue rendering
- Audio sync preserved because the error card has the exact duration
  of the failed shot

The error card is visible (darker cream, "rendering failed" label,
truncated error text) so you can see what failed during review.

### Impact

One bad shot now produces a visible error card in the timeline.
The video completes.  You can target the failed shot specifically
in the next pass instead of debugging an opaque crash.

## Files in the patch

| File | Location | Status |
|---|---|---|
| `plan.py` | `phase3/plan.py` | Replaces |
| `render.py` | `phase3/render.py` | Replaces |
| `sources_init.py` | `phase3/sources/__init__.py` | Replaces (renamed for zip clarity) |

## How to apply

```bash
cp plan.py phase3/plan.py
cp render.py phase3/render.py
cp sources_init.py phase3/sources/__init__.py
```

Then **regenerate the plan** before re-rendering — the merge pass runs
during plan validation, so existing saved plans don't benefit:

```bash
python phase3_run.py \
    --script  samples/al_askari_script.txt \
    --audio   output/al_askari_audio.mp3 \
    --plan-only \
    --book-title "مذكرات جعفر العسكري" \
    --character-name "Jafar al-Askari"
```

Then audit the new plan:

```bash
python audit_plan.py output/al_askari_plan_v2.json
```

You should see:
- Total shots: ~43 (down from 69)
- Auto-split: <10% (down from 72%)
- Plan timeline still matches audio duration

Then re-run the full render with `--verbose`:

```bash
python render_plan.py \
    --plan   output/al_askari_plan_v2.json \
    --audio  output/al_askari_audio.mp3 \
    --output output/final_cut.mp4 \
    --anthropic-key $ANTHROPIC_API_KEY \
    --pexels-key   $PEXELS_API_KEY \
    --book-title   "مذكرات جعفر العسكري" \
    --character-name "Jafar al-Askari" \
    --verbose
```

`--verbose` prints per-shot decisions in real time.  If anything still
crashes, the traceback now lands somewhere actionable instead of in
"few other steps then crashed".

## What I'd really like to see

If the crash recurs even with this defensive code in place — meaning
something raised at a layer I haven't anticipated — the full traceback
with `--verbose` is the gold standard.  Pipe it to a file:

```bash
python render_plan.py ... --verbose 2>&1 | tee output/render.log
```

Then paste the tail of `output/render.log`.  I can pinpoint the
exact line in seconds with the traceback.
